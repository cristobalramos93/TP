//JAIME VIEJO MARTINEZ
//CRISTOBAL RAMOS LAINA
package simulator.model;

import java.util.List;

public interface GravityLaws {
	public void apply(List<Body>bodies);
}
