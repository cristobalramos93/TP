# out.1.txt

  "-i resources/examples/ex1.2body.txt -o resources/output/out.1.txt -s 10000 -dt 10000 -gl nlug"

# out.2.txt

  "-i resources/examples/ex1.2body.txt -o resources/output/out.2.txt -s 10000 -dt 10000 -gl ftcg"
  
# out.3.txt

  "-i resources/examples/ex2.3body.txt -o resources/output/out.3.txt -s 10000 -dt 10000 -gl nlug"

# out.4.txt

  "-i resources/examples/ex2.3body.txt -o resources/output/out.4.txt -s 10000 -dt 10000 -gl ftcg"
  
# out.5.txt

  "-i resources/examples/ex3.4body.txt -o resources/output/out.5s.txt -s 10000 -gl nlug"

# out.6.txt

  "-i resources/examples/ex3.4body.txt -o resources/output/out.6s.txt -s 10000 -gl ftcg"
  
# out.7.txt

  "-i resources/examples/ex4.4body.txt -o resources/output/out.7s.txt -s 10000 -gl nlug"

# out.8.txt

  "-i resources/examples/ex4.4body.txt -o resources/output/out.8s.txt -s 10000 -gl ftcg"
  
# out.1s.txt

  "-i resources/examples/ex1.2body.txt -o resources/output/out.1s.txt -s 10000 -gl nlug"

# out.2s.txt

  "-i resources/examples/ex1.2body.txt -o resources/output/out.2s.txt -s 10000 -gl ftcg"
  
# out.3s.txt

  "-i resources/examples/ex2.3body.txt -o resources/output/out.3s.txt -s 10000 -gl nlug"

# out.4s.txt

  "-i resources/examples/ex2.3body.txt -o resources/output/out.4s.txt -s 10000 -gl ftcg"
  
# out.5s.txt

  "-i resources/examples/ex3.4body.txt -o resources/output/out.5s.txt -s 10000 -gl nlug"

# out.6s.txt

  "-i resources/examples/ex3.4body.txt -o resources/output/out.6s.txt -s 10000 -gl ftcg"
  
# out.7s.txt

  "-i resources/examples/ex4.4body.txt -o resources/output/out.7s.txt -s 10000 -gl nlug"

# out.8s.txt

  "-i resources/examples/ex4.4body.txt -o resources/output/out.8s.txt -s 10000 -gl ftcg"
  
  