//JAIME VIEJO MARTINEZ
//CRISTOBAL RAMOS LAINA
package simulator.model;

import java.util.ArrayList;
import java.util.List;

public class PhysicsSimulator {

	private double tiempoReal = 0.0, tiempoRealPasos;
	GravityLaws gravitylaw;
	List<Body> bodylist = new ArrayList<>();
	
	public PhysicsSimulator(double tiempoRealPasos, GravityLaws gravityLaw) throws Exception { //revisar
		if(tiempoRealPasos == 0.0) throw IllegalArgumentException();
		else this.tiempoRealPasos = tiempoRealPasos;
		if(gravityLaw == null) throw IllegalArgumentException();
		else this.gravitylaw = gravityLaw;
	}
	
	public void advance() {
		gravitylaw.apply(bodylist);
		for (int i = 0; i < bodylist.size(); i++) {
			bodylist.get(i).move(tiempoRealPasos);
		}
		tiempoReal += tiempoRealPasos;
	}
	
	public void addBody(Body b) throws Exception {
			for (int i = 0; i < bodylist.size(); i++) {
				if(bodylist.get(i).getId().equals(b.getId())) {
					throw IllegalArgumentException();
				}
			}
			bodylist.add(b);
	}

	public String toString() {
		return "{ \"time\": " + tiempoReal +", \"bodies\": " + bodylist.toString() +"}";	
	}
	
	private Exception IllegalArgumentException() {
		System.out.println("Illegal Argument when introducing body to list");		
		return null;
	}
}
