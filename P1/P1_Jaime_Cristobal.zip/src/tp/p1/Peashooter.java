package tp.p1;

public class Peashooter {
	
	
	
	private int x;
	private int y;
	private int coste;
	private int resistencia;
	private int danio;
	private int frecuencia;
	//private int alcance;
	
	public Peashooter(){}
	
	public Peashooter(int x, int y, int coste, int resistencia, int danio, int frecuencia) {
		super();
		this.x = x;
		this.y = y;
		this.coste = coste;
		this.resistencia = resistencia;
		this.danio = danio;
		this.frecuencia = frecuencia;
	}


	Game game;

	public int getResistencia() {
		return resistencia;
	}

	public int getCoste() {
		return coste;
	}

	public void setCoste(int coste) {
		this.coste = coste;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getDanio() {
		return danio;
	}

	public void setDanio(int danio) {
		this.danio = danio;
	}

	public void setResistencia(int resistencia) {
		this.resistencia = resistencia;
	}


	

	

}
