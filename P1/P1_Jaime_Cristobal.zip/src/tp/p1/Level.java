package tp.p1;

	
	
	public enum Level{
		EASY,
		HARD,
		INSANE
	}

	
