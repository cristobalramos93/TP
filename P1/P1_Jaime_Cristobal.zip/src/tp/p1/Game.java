package tp.p1;

import java.util.Random;

public class Game {


	private SunflowerList sunList;
	private PeashooterList peashooterList;
	public ZombieList zombielist;
	public int ciclos; //contador de ciclos, empieza en 1
	public Random rand;
	Sunflower sun;
	Peashooter pea;
	Zombie zom;
	Level level;
	SuncoinManager suncoin;
	public GamePrinterTemplate template;
	public int numZombies = 0;
	public int quedan = 100;



	public Game(SunflowerList sunList, PeashooterList peashooterList, ZombieList zombielist, int ciclos,Random seed,Level level,SuncoinManager suncoin,GamePrinterTemplate template) {
		this.sunList = sunList;
		this.peashooterList = peashooterList;
		this.zombielist = zombielist;
		this.ciclos = ciclos;
		this.rand = seed;
		this.level = level;
		this.suncoin = suncoin;
		this.template = template;
	}
	

	public void userCommand(int x, int y, String valor) { //actualiza el estado de todos los elementos del juego
		if(x > 3 || y > 7 || x < 0 || y < 0) {
			System.out.println("Posiciones fuera del rango del tablero");
		}
		
		else if( template.isEmpty(x,y)) {
			char para = valor.charAt(0);
			if(para == 's' || para == 'S') {
				if(suncoin.getSuncoins() - 20 >= 0) { // comprueba que tenga soles suficientes
				suncoin.setSuncoins(suncoin.getSuncoins() - 20);
				sun = new Sunflower(x, y, 20, 1, 0, 10,ciclos);
				sunList.aniadir(sun); //crea un nuevo girasol en la lista de girasoles
				template.setBoard('S', x, y, sun.getResistencia());
				update();

				//this.board.setCell(x, y, valor,sun.getResistencia());
			}
			else System.out.println("No tienes soles suficientes!");
	
			}
			if(para == 'p' || para == 'P') {
				if(suncoin.getSuncoins() - 50 >= 0) { // comprueba que tenga soles suficientes
				suncoin.setSuncoins(suncoin.getSuncoins() - 50);
				pea = new Peashooter(x, y, 50, 3, 1, 10);
				peashooterList.aniadir(pea); //crea un nuevo guisante en la lista de guisantes
				template.setBoard('P', x, y, pea.getResistencia());
				//this.board.setCell(x, y, valor,pea.getResistencia());
				update();

				}
				else System.out.println("No tienes soles suficientes!");
	
			}

		}
		else System.out.println("Esta celda esta ocupada");

	}
	
	public void update() {
		
		sumaSoles();
		ataca();
		atacaZombie();
		avanza();
		muerte();
		numZombies = ZombieManager.computerAction(level,rand,template,zombielist,numZombies,zom,quedan); // aparicion de zombie y devuelvo el contador de zombies
		ciclos++;
		System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
		System.out.println("Number of cycles: " + (ciclos-1));
		System.out.println("Sun coins: " + suncoin.getSuncoins());
		quedan = zombiesQuedan();
		System.out.println("Remaining zombies: " + quedan); //zombies que quedan por salir
		
		System.out.println(template.toString());
	}

	public int getCiclos() {
		return ciclos;
	}
	
		public void sumaSoles() { // para cada girasol suma soles si llevan dos turnos sin dar
			
			for(int i = 0; i < sunList.ultimaPos(); i++) {
				if((ciclos - sunList.sun(i).getCiclo()) %3 == 0 && ciclos - sunList.sun(i).getCiclo() != 0 ) { //si desde que le an puesto, lleva un turno sin dar
					suncoin.setSuncoins(suncoin.getSuncoins() + sunList.sun(i).getFrecuencia()); //si le toca hace soles totales + 10
				}
			}

		}

		public void ataca() { // de la lista de guisantes, busca si hay zombies en su fila de la lista de zombies
			for(int i = 0; i < peashooterList.ultimaPos(); i++) {
				boolean atacado = false;
				for(int j = 0; j < zombielist.tamano(); j++) {
					if( peashooterList.pea(i).getX() == zombielist.zom(j).getX() && zombielist.zom(j).getResistencia() > 0 && !atacado) { //si esta en su fila y esta vivo
						zombielist.zom(j).setResistencia(zombielist.zom(j).getResistencia() - peashooterList.pea(i).getDanio()); // ataca
						atacado = true; //para que solo ataque una vez
						template.setBoard('Z', zombielist.zom(j).getX(), zombielist.zom(j).getY(), zombielist.zom(j).getResistencia());//modifico tablero

					}
				}
				
			}
		}
		
		
		public void avanza() { //los zombies avanzan una casilla a la izquierda (si pueden)
			for(int i = 0; i < zombielist.tamano(); i++) {
				if(zombielist.zom(i).getResistencia() > 0 && template.isEmpty(zombielist.zom(i).getX(), zombielist.zom(i).getY() -1)) { //si esta vivo y no tiene nada a la izquierda
				template.setBoardVacia(zombielist.zom(i).getX(), zombielist.zom(i).getY()); //borro del tablero donde estaba antes
				zombielist.zom(i).setY(zombielist.zom(i).getY() - zombielist.zom(i).getVelocidad()); //modifico en la lista de zombies
				template.setBoard('Z', zombielist.zom(i).getX(), zombielist.zom(i).getY(), zombielist.zom(i).getResistencia());//modifico en tablero
				//template.setBoardVacia(zombielist.zom(i).getX(), zombielist.zom(i).getY()); //borro del tablero donde estaba antes
				}
			}
		}

		
		public void atacaZombie() { // de la lista de guisantes, busca si hay zombies en su fila de la lista de zombies
			
			for(int i = 0; i < zombielist.tamano(); i++) { //ataca a guisante
				for(int j = 0; j < peashooterList.ultimaPos(); j++) {
					if(zombielist.zom(i).getResistencia() > 0) { //si esta vivo
						if(zombielist.zom(i).getX() == peashooterList.pea(j).getX() && zombielist.zom(i).getY() == peashooterList.pea(j).getY() + 1) { //si esta a su izquierda
							peashooterList.pea(j).setResistencia(peashooterList.pea(j).getResistencia() - zombielist.zom(i).getDanio()); //le quita uno de danio en la lista
							template.setBoard('P', peashooterList.pea(j).getX(), peashooterList.pea(j).getY(), peashooterList.pea(j).getResistencia()); //modifico tablero
						}
					}
				}
			}
			
			for(int i = 0; i < zombielist.tamano(); i++) { //ataca a un girasol
				for(int j = 0; j < sunList.ultimaPos(); j++) {
					if(zombielist.zom(i).getResistencia() > 0) {//si esta vivo
						if(zombielist.zom(i).getX() == sunList.sun(j).getX() && zombielist.zom(i).getY() == sunList.sun(j).getY() + 1) { //si esta a su izquierda
							sunList.sun(j).setResistencia(sunList.sun(j).getResistencia() - zombielist.zom(i).getDanio()); //le quita uno de danio en la lista
							template.setBoard('S', sunList.sun(j).getX(), sunList.sun(j).getY(), sunList.sun(j).getResistencia()); //modifico tablero
						}
					}
				}
			}
			
		}
		

		
		public void muerte() {
			for(int i = 0; i < zombielist.tamano(); i++) {
				if(zombielist.zom(i).getResistencia() == 0) {
					template.setBoardVacia(zombielist.zom(i).getX(), zombielist.zom(i).getY()); //borro de tablero
					zombielist.borrar(i); //borro de la lista
					i--;
				}
			}
			
			for(int i = 0; i < peashooterList.ultimaPos(); i++) {
				if(peashooterList.pea(i).getResistencia() == 0) {
					template.setBoardVacia(peashooterList.pea(i).getX(), peashooterList.pea(i).getY()); //borro de tablero
					peashooterList.borrar(i); //borro de la lista
					i--;
				}
			}
			
			for(int i = 0; i < sunList.ultimaPos(); i++) {
				if(sunList.sun(i).getResistencia() == 0) {
					template.setBoardVacia(sunList.sun(i).getX(), sunList.sun(i).getY()); //borro de tablero
					sunList.borrar(i); //borro de la lista
					i--;
				}
			}
			
		}
		
		
		
		
		
		
		
	public boolean hasPerdido() {
		boolean perder = false;
		for(int i = 0; i < zombielist.tamano(); i++) {
			if(zombielist.zom(i).getY() == 0) {
				perder = true;
			}
		}
		return perder;

	}
	
	public boolean hasGanado() {
		boolean ganado = false;
		
		if(level.INSANE == level && zombielist.tamano() == 0) {
			if(numZombies == 10) {
				ganado = true;
			}
		}
		if(level.EASY == level && zombielist.tamano() == 0) {
				if(numZombies == 3) {
					ganado = true;
				}
		}
		if(level.HARD == level) {
			if(numZombies == 5 && zombielist.tamano() == 0) {
				ganado = true;
			}
		}
		return ganado;
	}

	public Level getLevel() {
		return level;
	}
		
	public int zombiesQuedan(){
		int quedan = 100;
		if(level.INSANE == level) {
			quedan = 10-numZombies;
		}
		if(level.EASY == level) {
			quedan = 3-numZombies;

		}
		if(level.HARD == level) {
			quedan = 5-numZombies;

		}
		return quedan;
		
	}
		
}
