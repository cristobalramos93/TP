package tp.p1;

public class SuncoinManager {
	
	
	private int suncoins;//lleva el control de los suncoins

	public SuncoinManager(int suncoins) {
		this.suncoins = suncoins;
	}

	public int getSuncoins() {
		return suncoins;
	}

	public void setSuncoins(int suncoins) {
		this.suncoins = suncoins;
	}

	
	
}
