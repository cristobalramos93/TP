package tp.p1;

public class ZombieList {

	private Zombie[] ZombieList;


	ZombieList(){
		ZombieList=new Zombie[0];

	}
	
	

	public Zombie[] getZombieList() {
		return ZombieList;
	}

	public void setZombieList(Zombie[] zombieList) {
		ZombieList = zombieList;
	}

	
	
	public void aniadir(Zombie pea) {
		Zombie[] aux=ZombieList;
		ZombieList=new Zombie[ZombieList.length+1];
		for(int i=0; i<aux.length;i++) {
			ZombieList[i]=aux[i];
		}
		ZombieList[ZombieList.length-1] = pea;
	}
	
	public int tamano() {
		return ZombieList.length;
	}
	
	public Zombie zom(int i) {
		return ZombieList[i];
	}
	
	
	public void borrar(int i) {

		if(i == ZombieList.length-1) { //si es el ultimo se borra
			ZombieList[i] = null;
		}
		else {
			for(int n = i ;  n < ZombieList.length - 1; n++ ) {
				ZombieList[n] = ZombieList[n+1];
			}
			ZombieList[ZombieList.length-1] = null;
		}
		

		Zombie[] aux=ZombieList;
		ZombieList=new Zombie[ZombieList.length-1];
		for(int j=0; j<aux.length -1;j++) {
			ZombieList[j]=aux[j];
		}
		
	}

	
	
	
	
	
	
	
	
	
}
