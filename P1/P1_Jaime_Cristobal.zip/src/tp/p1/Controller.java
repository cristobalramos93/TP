package tp.p1;

import java.util.Random;
import java.util.Scanner;

public class Controller {
	private boolean perder = false;
	private boolean ganar = false;
	private int quedan;
	private Game game;
	private Scanner in;
	PlantsVsZombies pz;
	GamePrinterTemplate template;
	ZombieList zom;
	Level level;
	public Controller(Game game, Scanner in) {
		this.game = game;
		this.in = in;
	}

	public void run() {
		//System.out.println("Welcome to Zombies" + '\n');
		
		
		System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
		System.out.println("Number of cycles: " + (game.getCiclos()-1));
		System.out.println("Sun coins: " + game.suncoin.getSuncoins());
		quedan = game.zombiesQuedan();
		System.out.println("Remaining zombies: " + quedan); //zombies que quedan por salir+ 
				
		
		
		System.out.println(game.template.toString());
		String[] comando;
		System.out.println("Command > ");
		comando = in.nextLine().split(" ");
		while( !comando[0].equalsIgnoreCase("e") && !perder && !ganar) {
			if(  comando.length == 4 && comando[0].equalsIgnoreCase("a") && (comando[1].equalsIgnoreCase("p") || comando[1].equalsIgnoreCase("s") ||comando[1].equalsIgnoreCase("peashooter") || comando[1].equalsIgnoreCase("sunflower") ) ){
				this.game.userCommand(Integer.parseInt(comando[2]),Integer.parseInt(comando[3]),comando[1]);
				perder = game.hasPerdido();
				ganar = game.hasGanado();
				
			}
			
			else if(comando[0].equalsIgnoreCase("r") && comando.length == 1) {
				game = new Game(new SunflowerList(),new PeashooterList(),new ZombieList(),1,PlantsVsZombies.getSeed(),game.getLevel(),new SuncoinManager(pz.getSoles()),new GamePrinterTemplate(4,8));
				System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
				System.out.println("Number of cycles: " + (game.getCiclos()-1));
				System.out.println("Sun coins: " + game.suncoin.getSuncoins());
				quedan = game.zombiesQuedan();
				System.out.println("Remaining zombies: " + quedan); //zombies que quedan por salir+ 
						
				
				
				System.out.println(game.template.toString());
				//run();
			}
			else if(comando[0].equalsIgnoreCase("l") && comando.length == 1) {
				mostrarList();
			}
			else if((comando[0].equalsIgnoreCase("") || comando[0].equalsIgnoreCase("n")) && comando.length == 1) {
				game.update();
				perder = game.hasPerdido();
				ganar = game.hasGanado();
			}

			else if(comando[0].equalsIgnoreCase("h") && comando.length == 1) {
				mostrarHelp();
			}else {
				System.out.println("Comando no valido. Escribe help para ver la ayuda");
			}
		
			if(!ganar && !perder) {
			System.out.println("Command > ");
			comando = in.nextLine().split(" ");
			}
		

		}
		if(comando[0].equalsIgnoreCase("e")) {
			System.out.println("Has pulsado exit. Game Over!");
		}
		else if(perder) {
			System.out.println("Has perdido!");
		}
		else if(ganar) System.out.println("Has ganado!");
	}
	
	
	private void mostrarHelp() {
		System.out.println("Add <plant> <x> <y>: Adds a plant in position x, y");
		System.out.println("List: Prints the list of available plants.");
		System.out.println("Reset: Starts a new game.");
		System.out.println("Help: Prints this help message.");
		System.out.println("Exit: Terminates the program.");
		System.out.println("[none]: Skips cycle.");
	}
	
	private void mostrarList() {
		System.out.println("[S]unflower: Cost: 20 suncoins  Harm: 0");
		System.out.println("[P]eashooter: Cost: 50 suncoins  Harm: 1");
		//System.out.println("[S]unflower: Cost:" + game.sun.getCoste()+" suncoins  Harm: " + game.sun.getDanio());
		//System.out.println("[P]eashooter: Cost:" + game.pea.getCoste()+" suncoins  Harm: " + game.pea.getDanio());
	}
		
}
