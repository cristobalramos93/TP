package tp.p1;

import java.util.Random;
import java.util.Scanner;


public class PlantsVsZombies {
	private static Random seed;
	static int semilla;
	final static int soles = 50;
	
	public static int getSoles() {
		return soles;
	}

	public static void main(String[] args) {
		Game game = null;
		Level level = null;
		if(args.length == 1) {
			semilla = new Random().nextInt(1000);
			seed = new Random(semilla);
			if(args[0].equalsIgnoreCase("easy")) { 
				game = new Game(new SunflowerList(),new PeashooterList(),new ZombieList(),1,seed,level.EASY,new SuncoinManager(soles),new GamePrinterTemplate(4,8));
			}
			else if(args[0].equalsIgnoreCase("hard")) { 
				game = new Game(new SunflowerList(),new PeashooterList(),new ZombieList(),1,seed,level.HARD,new SuncoinManager(soles),new GamePrinterTemplate(4,8));
			}
			else game = new Game(new SunflowerList(),new PeashooterList(),new ZombieList(),1,seed,level.INSANE,new SuncoinManager(soles),new GamePrinterTemplate(4,8));

		
		}
		
		if(args.length == 2) {
			semilla = Integer.parseInt(args[1]);
			seed = new Random(semilla);
			if(args[0].equalsIgnoreCase("easy")) { 
				game = new Game(new SunflowerList(),new PeashooterList(),new ZombieList(),1,seed,level.EASY,new SuncoinManager(soles),new GamePrinterTemplate(4,8));
			}
			else if(args[0].equalsIgnoreCase("hard")) { 
				game = new Game(new SunflowerList(),new PeashooterList(),new ZombieList(),1,seed,level.HARD,new SuncoinManager(soles),new GamePrinterTemplate(4,8));
			}
			else game = new Game(new SunflowerList(),new PeashooterList(),new ZombieList(),1,seed,level.INSANE,new SuncoinManager(soles),new GamePrinterTemplate(4,8));

		}
		
		
		
		
		Controller controlador = new Controller(game, new Scanner(System.in));
		controlador.run();
	}

	public static Random getSeed() {
		return seed;
	}
	
	public static int getSemilla() {
		return semilla;
	}
}
