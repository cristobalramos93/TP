package tp.p1;

public class Zombie {

	
	
	public Zombie(int x, int y, int resistencia, int danio,int velocidad) {
		this.x = x;
		this.y = y;
		this.resistencia = resistencia;
		this.danio = danio;
		this.velocidad = velocidad;
	}


	public int getResistencia() {
		return resistencia;
	}


	private int x;
	private int y;
	private int resistencia;
	private int danio;
	private int velocidad;
	Game game;
	
	public int getX() {
		return x;
	}


	public int getVelocidad() {
		return velocidad;
	}


	public int getY() {
		return y;
	}


	public void setX(int x) {
		this.x = x;
	}


	public void setY(int y) {
		this.y = y;
	}


	public void setResistencia(int resistencia) {
		this.resistencia = resistencia;
	}


	public int getDanio() {
		return danio;
	}


	public void setDanio(int danio) {
		this.danio = danio;
	}
	
	


}
