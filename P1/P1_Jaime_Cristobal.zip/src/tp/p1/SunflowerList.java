package tp.p1;

public class SunflowerList {

	private Sunflower[] SunflowerList;

	SunflowerList(){
		SunflowerList=new Sunflower[0];
	}
	
	

	public Sunflower[] getSunflowerList() {
		return SunflowerList;
	}

	public void setSunflowerList(Sunflower[] sunflowerList) {
		SunflowerList = sunflowerList;
	}
	
	public Sunflower sun(int i) { //devuelve un girasol de la lista
		return SunflowerList[i];
	}

	
	public int ultimaPos() {
		
		return SunflowerList.length;
	}
	
	public void aniadir(Sunflower pea) {
		Sunflower[] aux=SunflowerList;
		SunflowerList=new Sunflower[SunflowerList.length+1];
		for(int i=0; i<aux.length;i++) {
			SunflowerList[i]=aux[i];
		}
		SunflowerList[SunflowerList.length-1] = pea;
	}
	
	public void borrar(int i) {
		if(i == SunflowerList.length-1) { //si es el ultimo se borra
			SunflowerList[i] = null;
		}
		else {
			for(int n = i ;  n < SunflowerList.length - 1; n++ ) {
				SunflowerList[n] = SunflowerList[n+1];
			}
			SunflowerList[SunflowerList.length-1] = null;
		}
		

		Sunflower[] aux=SunflowerList;
		SunflowerList=new Sunflower[SunflowerList.length-1];
		for(int j=0; j<aux.length -1;j++) {
			SunflowerList[j]=aux[j];
		}
		
	}

}
