package tp.p1;

public class PeashooterList {

	private Peashooter[] PeashooterList;

	PeashooterList(){
		PeashooterList=new Peashooter[0];
	}
	
	
	public Peashooter[] getPeashooterList() {
		return PeashooterList;
	}

	public void setPeashooterList(Peashooter[] peashooterList) {
		PeashooterList = peashooterList;
	}

	
	public int ultimaPos() {
		
		return PeashooterList.length;
	}
	
	public Peashooter pea(int i) { //devuelve un guisante de la lista
		return PeashooterList[i];
	}

	
	public void aniadir(Peashooter pea) {
		Peashooter[] aux=PeashooterList;
		PeashooterList=new Peashooter[PeashooterList.length+1];
		for(int i=0; i<aux.length;i++) {
			PeashooterList[i]=aux[i];
		}
		PeashooterList[PeashooterList.length-1] = pea;
	}
	
	
	public void borrar(int i) { //muerte de un guisante

		if(i == PeashooterList.length-1) { //si es el ultimo se borra
			PeashooterList[i] = null;
		}
		else {
			for(int n = i ;  n < PeashooterList.length - 1; n++ ) {
				PeashooterList[n] = PeashooterList[n+1];
			}
			PeashooterList[PeashooterList.length-1] = null;
		}
		

		Peashooter[] aux=PeashooterList; //utilizamos un auxiliar para cambiar el .length
		PeashooterList=new Peashooter[PeashooterList.length-1];
		for(int j=0; j<aux.length -1;j++) {
			PeashooterList[j]=aux[j];
		}
		
	}
}
