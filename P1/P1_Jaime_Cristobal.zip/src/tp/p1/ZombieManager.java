package tp.p1;

import java.util.Random;

public class ZombieManager {
		
	public static int computerAction(Level level,Random rand, GamePrinterTemplate template, ZombieList zombielist,int numZombies,Zombie zom,int quedan) {//aparicion de zombie
		//System.out.println("Estos quedan: " + quedan);
		if(quedan != 0) {
		boolean existe = false;
		int x = rand.nextInt(4);
		int probabilidad = rand.nextInt(9);
		int y =7;
		if(level == level.EASY) {
			if(probabilidad == 0) { // 1 entre 10
				while(!existe) {
					if(template.isEmpty(x, y)) {
						existe = true;
					}
					else {
						 x = rand.nextInt(4);
					}
				}
				zom = new Zombie(x,y,5,1,1);
				zombielist.aniadir(zom);
				template.setBoard('Z', x, y,zom.getResistencia() );
				numZombies++;
				
			}
		}
		else if(level == level.HARD) {
			if(probabilidad == 1 || probabilidad == 2 || probabilidad == 0 || probabilidad == 3 || probabilidad == 4) { //1 entre 2
				while(!existe) {
					if(template.isEmpty(x, y)) {
						existe = true;
					}
					else {
						 x = rand.nextInt(4);
					}
				}
				zom = new Zombie(x,y,5,1,1);
				zombielist.aniadir(zom);
				template.setBoard('Z', x, y,zom.getResistencia() );
				numZombies++;
				
			}
		}
		else if(level == level.INSANE) {
			if(probabilidad != 0 && probabilidad != 1 && probabilidad != 2) { //7 entre 10
				while(!existe) {
					if(template.isEmpty(x, y)) {
						existe = true;
					}
					else {
						 x = rand.nextInt(4);
					}
				}
				zom = new Zombie(x,y,5,1,1);
				zombielist.aniadir(zom);
				template.setBoard('Z', x, y,zom.getResistencia() );
				numZombies++;

				
			}
		}
		}
		return numZombies;
	}
	
	


}
