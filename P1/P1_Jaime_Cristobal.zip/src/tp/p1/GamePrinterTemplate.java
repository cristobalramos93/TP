package tp.p1;

public class GamePrinterTemplate {
	int dimX; 
	int dimY;
	String[][] board;
	final String space = " ";
	
	

	public SuncoinManager getCoins() {
		return coins;
	}
	SuncoinManager coins;
	Game game;
	
	public GamePrinterTemplate( int dimX, int dimY) {
		this.dimX = dimX;
		this.dimY = dimY;
		
		encodeGame();
	}
	public boolean isEmpty(int x, int y){ //si el valor de la celda es Z devuelve true
		  
		  if(board[x][y] == space){
		   return true;
		  }
		  else return false;

		 }
	
	private void encodeGame() {
		board = new String[dimX][dimY];
		for(int i = 0; i < dimX; i++) {
			for(int j = 0; j < dimY; j++) {

				board[i][j] =  space;
				// TODO Fill the board with simulation objects
			}
		}


	}
	
	
	
	public String[][] getBoard() {
		return board;
	}
	public void setBoard(char c, int x, int y, int res) {
		this.board[x][y] = c + " [" + res + "]" ;
	}
	
	public void setBoardVacia(int x, int y) {
		board[x][y] =  space;
	}
	public String toString() {

		int cellSize = 7;
		int marginSize = 2;
		String vDelimiter = "|";
		String hDelimiter = "-";
		
		String rowDelimiter = GamePrinter.repeat(hDelimiter, (dimY * (cellSize + 1)) - 1);
		String margin = GamePrinter.repeat(space, marginSize);
		String lineDelimiter = String.format("%n%s%s%n", margin + space, rowDelimiter);
		
		StringBuilder str = new StringBuilder();
		
		str.append(lineDelimiter);
		
		for(int i=0; i<dimX; i++) {
				str.append(margin).append(vDelimiter);
				for (int j=0; j<dimY; j++) {
					str.append( GamePrinter.centre(board[i][j], cellSize)).append(vDelimiter);
				}
				str.append(lineDelimiter);
		}
		return str.toString();
	}
}
