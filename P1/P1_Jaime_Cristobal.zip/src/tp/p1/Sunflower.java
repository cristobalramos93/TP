package tp.p1;

public class Sunflower {
	
	
	
	
	
	private int x;
	private int y;
	private int coste;
	private int resistencia;
	private int danio;
	private int frecuencia;
	private int ciclo;
	Game game;
	
	

	public Sunflower(int x, int y, int coste, int resistencia, int danio, int frecuencia, int ciclo) {
		super();
		this.x = x;
		this.y = y;
		this.coste = coste;
		this.resistencia = resistencia;
		this.danio = danio;
		this.frecuencia = frecuencia;
		this.ciclo = ciclo;
	}



	public int getResistencia() {
		return resistencia;
	}

	public int getCiclo() {
		return ciclo;
	}



	public int getX() {
		return x;
	}



	public void setX(int x) {
		this.x = x;
	}



	public void setResistencia(int resistencia) {
		this.resistencia = resistencia;
	}



	public int getY() {
		return y;
	}



	public void setY(int y) {
		this.y = y;
	}



	public int getCoste() {
		return coste;
	}



	public void setCoste(int coste) {
		this.coste = coste;
	}



	public int getDanio() {
		return danio;
	}



	public void setDanio(int danio) {
		this.danio = danio;
	}



	public int getFrecuencia() {
		return frecuencia;
	}



	public void setFrecuencia(int frecuencia) {
		this.frecuencia = frecuencia;
	}
	

}
