package tp.p2;

import java.util.Random;


import commands.GameObject;
import commands.GameObjectList;
import commands.Plants;
import commands.Zombies;
import commands.ZombiesFactory;

public class Game {

	GameObject obj;
	private Plants planta;
	public int ciclos; //contador de ciclos, empieza en 1
	public Random rand;
	Sunflower sun;
	Peashooter pea;
	//Zombie zom;
	Level level;
	SuncoinManager suncoin;
	//public GamePrinterTemplate template;
	public int numZombies = 0;
	public int quedan = 100;
	private boolean fin = false;
	PlantsVsZombies pz;
	private GameObjectList objectList;
	private BoardPrinter printer;

	public Game(int ciclos,Random seed,Level level,SuncoinManager suncoin/*,GamePrinterTemplate template*/,GameObjectList objectList,BoardPrinter printer) {
		this.ciclos = ciclos;
		this.rand = seed;
		this.level = level;
		this.suncoin = suncoin;
		//this.template = template;
		this.objectList = objectList;
		this.printer = printer;
	}
	

	public void update() {
		
		sumaSoles();
		//atacaPeashooter();
		//atacaCereza();
		atacaPlantas();
		atacaZombie();
		avanzanZombies();
		//avanzaZombieNormal();
		muerte();
		numZombies = ZombiesFactory.getZombie(level,rand,printer,numZombies,quedan, this); // aparicion de zombie y devuelvo el contador de zombies
		ciclos++;
		
		/*
		System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
		System.out.println("Number of cycles: " + (ciclos-1));
		System.out.println("Sun coins: " + suncoin.getSuncoins());
		quedan = zombiesQuedan();
		System.out.println("Remaining zombies: " + quedan); //zombies que quedan por salir
		*/
		//System.out.println(template.toString());
	}
	
	
	public void atacaPlantas() { //cada una ataca en su clase, de esta manera lo hacen por orden de creacion
		for(int i = 0; i < objectList.ultimaPos(); i++) {
			if(objectList.getObjeto(i).getLetra() == 'P' || objectList.getObjeto(i).getLetra() == 'C') {
				planta = (Plants) objectList.getObjeto(i);
				planta.ataca(objectList,printer,this);
			}
		}
	}
	
	public BoardPrinter getPrinter() {
		return printer;
	}


	public void setPrinter(BoardPrinter printer) {
		this.printer = printer;
	}


	public int getCiclos() {
		return ciclos;
	}
	
		public void sumaSoles() { // para cada girasol suma soles si llevan dos turnos sin dar
			
			for(int i = 0; i < objectList.ultimaPos(); i++) {
				if(objectList.getObjeto(i).getLetra() == 'S') {
					sun = (Sunflower) objectList.getObjeto(i);
					int res;
					res = (ciclos-sun.getCiclo()) %sun.getFrecuencia();
				if(res == 0) { 
					if(ciclos-sun.getCiclo() != 0) {//si desde que le an puesto, lleva un turno sin dar
					suncoin.setSuncoins(suncoin.getSuncoins() + 10); //si le toca hace soles totales + 10
					}
				}
			}
			}

		}
		
		
		Zombies zombie;
		public void avanzanZombies() {
			for(int i = 0; i < objectList.ultimaPos(); i++) {
				if(objectList.getObjeto(i).getLetra() == 'Z' || objectList.getObjeto(i).getLetra() == 'W' || objectList.getObjeto(i).getLetra() == 'X') {
					zombie = (Zombies) objectList.getObjeto(i);
					zombie.avanza(this,printer,objectList);
				}
			}
		}
		
		public void atacaZombie() { // de la lista de guisantes, busca si hay zombies en su fila de la lista de zombies
			
			Zombies zom;
			for(int i = 0; i < objectList.ultimaPos(); i++) { //ataca a guisante
				if(objectList.getObjeto(i).getLetra() == 'Z' || objectList.getObjeto(i).getLetra() == 'X' || objectList.getObjeto(i).getLetra() == 'W' ) {
				for(int j = 0; j < objectList.ultimaPos(); j++) {
					if(objectList.getObjeto(j).getLetra() == 'P' || objectList.getObjeto(j).getLetra() == 'S' || objectList.getObjeto(j).getLetra() == 'C' || objectList.getObjeto(j).getLetra() == 'N') {
					if(objectList.getObjeto(i).getVida() > 0) { //si esta vivo
						if(objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX() && objectList.getObjeto(i).getY() == objectList.getObjeto(j).getY() + 1) { //si esta a su izquierda
							
							
							if(objectList.getObjeto(i).getLetra() == 'Z') {
								zom = (Zombie) objectList.getObjeto(i);
							}
							else if(objectList.getObjeto(i).getLetra() == 'X') {
								zom = (ZombieDeportista) objectList.getObjeto(i);
							}
							else zom = (ZombieLento) objectList.getObjeto(i);

							
							//zom = (Zombie) objectList.getObjeto(i);
							objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - zom.getDanio()); //le quita uno de danio en la lista
							//printer.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero
						}
						}
					}
					}
				}
			}
		}
			
			public void muerte() {
				
				for(int i = 0; i < objectList.ultimaPos(); i++) {
					if(objectList.getObjeto(i).getVida() <= 0) {
						//printer.setBoardVacia(objectList.getObjeto(i).getX(), objectList.getObjeto(i).getY()); //borro de tablero
						objectList.borrar(i); //borro de la lista
						i--;
					}
				}
				
			}
			
			public void hasPerdido() {
				
				if(fin == false) {
				for(int i = 0; i < objectList.ultimaPos(); i++) {
					if((objectList.getObjeto(i).getLetra() == 'Z' || objectList.getObjeto(i).getLetra() == 'W' || objectList.getObjeto(i).getLetra() == 'X' ) && objectList.getObjeto(i).getY() == 0) {
						fin = true;
					}
				}
				if(fin == true) {
					System.out.println(printer.toString(this,objectList));
					System.out.println("Has perdido!");

				}
				}
			}
			
			public void hasGanado() {
				int cont = 0;
				if (fin != true) {
					for(int i = 0; i < objectList.ultimaPos(); i++) {
						if(objectList.getObjeto(i).getLetra() == 'Z' || objectList.getObjeto(i).getLetra() == 'W' || objectList.getObjeto(i).getLetra() == 'X' ) cont ++;
					}
					if(level.INSANE == level && cont == 0) {
						if(numZombies == 10) {
							fin = true;
						}
					}
					if(level.EASY == level && cont == 0) {
							if(numZombies == 3) {
								fin = true;
							}
					}
					if(level.HARD == level) {
						if(numZombies == 5 && cont == 0) {
							fin = true;
						}
					}
					if(fin == true) {
						System.out.println(printer.toString(this,objectList));
						//System.out.println(game.getPrinter().toString(game));

						System.out.println("Has ganado!");
					}
				}
			}

			public Level getLevel() {
				return level;
			}
				
			public int zombiesQuedan(){
				if(level.INSANE == level) {
					quedan = 10-numZombies;
				}
				if(level.EASY == level) {
					quedan = 3-numZombies;

				}
				if(level.HARD == level) {
					quedan = 5-numZombies;

				}
				return quedan;
				
			}
			
			
			
			public boolean isFin() {
				return fin;
			}
			
			
			
			
			
			public void setFin(boolean fin) {
				this.fin = fin;
			}
			
			
			
			
			public Random getRand() {
				return rand;
			}


			public void reset() {
			//	new Game(new SunflowerList(),new PeashooterList(),new ZombieList(),1,PlantsVsZombies.getSeed(),getLevel(),new SuncoinManager(pz.getSoles()),new GamePrinterTemplate(4,8));
				this.ciclos = 1;
				this.suncoin = new SuncoinManager(pz.getSoles());
				//this.printer = new ReleasePrinter(4, 8,objectList,this);
				this.numZombies = 0;
				this.objectList = new GameObjectList();
				quedan = zombiesQuedan();
			}
			
			public void cambioDeTablero(BoardPrinter printer) {
				//	public Game(int ciclos,Random seed,Level level,SuncoinManager suncoin,GamePrinterTemplate template,GameObjectList objectList,BoardPrinter printer) {
				this.printer = printer;

			}
			
			public boolean addPlantToGame(int x, int y, Plants planta) {
				boolean puesto = false;
				//obj = new GameObject()
				//obj = planta;
			//	obj = new GameObject(x,y,planta.getVida(),planta.getDanio());
				if(x > 3 || y > 6 || x < 0 || y < 0) {
					System.out.println("Posiciones fuera del rango del tablero o en la ultima columna(7)");
				}
				
				else if( printer.isEmpty(x,y,objectList)) {
						puesto = true;
						if(suncoin.getSuncoins() - planta.getCoste() >= 0) { // comprueba que tenga soles suficientes
						suncoin.setSuncoins(suncoin.getSuncoins() - planta.getCoste());
						objectList.aniadir(planta);
						//printer.setBoard(planta.getLetra(), x, y, planta.getVida());
						update();

						//this.board.setCell(x, y, valor,sun.getResistencia());
					}
					else System.out.println("No tienes soles suficientes!");
			
					}
				else System.out.println("posicion ya ocupada");
				//objectList.aniadir(planta);
				//planta.
				return puesto;
			}
			
			
			
			
			
			
			
			public GameObjectList getObjectList() {
				return objectList;
			}


			public void setObjectList(GameObjectList objectList) {
				this.objectList = objectList;
			}


			public void nuevoZombie(Zombies zom) {
				objectList.aniadir(zom);
				//printer.setBoard(zom.getLetra(), zom.getX(), zom.getY(), zom.getVida());
			}
			
}
			/*
			public void userCommand(int x, int y, String valor) { //actualiza el estado de todos los elementos del juego
				
				if(x > 3 || y > 7 || x < 0 || y < 0) {
					System.out.println("Posiciones fuera del rango del tablero");
				}
				
				else if( template.isEmpty(x,y)) {
					char para = valor.charAt(0);
					if(para == 's' || para == 'S') {
						if(suncoin.getSuncoins() - 20 >= 0) { // comprueba que tenga soles suficientes
						suncoin.setSuncoins(suncoin.getSuncoins() - 20);
						sun = new Sunflower(x, y, 20, 1, 0, 10,ciclos,"s");
						sunList.aniadir(sun); //crea un nuevo girasol en la lista de girasoles
						template.setBoard('S', x, y, sun.getResistencia());
						update();

						//this.board.setCell(x, y, valor,sun.getResistencia());
					}
					else System.out.println("No tienes soles suficientes!");
			
					}
					if(para == 'p' || para == 'P') {
						if(suncoin.getSuncoins() - 50 >= 0) { // comprueba que tenga soles suficientes
						suncoin.setSuncoins(suncoin.getSuncoins() - 50);
						pea = new Peashooter(x, y, 50, 3, 1, 1,"l");
						peashooterList.aniadir(pea); //crea un nuevo guisante en la lista de guisantes
						template.setBoard('P', x, y, pea.getResistencia());
						//this.board.setCell(x, y, valor,pea.getResistencia());
						update();

						}
						else System.out.println("No tienes soles suficientes!");
			
					}

				}
				else System.out.println("Esta celda esta ocupada");
			*/
			

		
/*
		public void atacaPeashooter() { // de la lista de guisantes, busca si hay zombies en su fila de la lista de zombies
			for(int i = 0; i < objectList.ultimaPos(); i++) {
				if(objectList.getObjeto(i).getLetra() == 'P') { //si de la lista, es un lanzaguisantes
				boolean atacado = false;
				for(int j = 0; j < objectList.ultimaPos(); j++) {
					//Plants planta2;
					//planta2 = (Plants) objectList.getObjeto(i);
					if((objectList.getObjeto(j).getLetra() == 'Z'|| objectList.getObjeto(j).getLetra() == 'W' || objectList.getObjeto(j).getLetra() == 'X' ) && objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX() && objectList.getObjeto(j).getVida() > 0 && !atacado) { //si esta en su fila y esta vivo y si es un zombie
						//System.out.println(planta2.getDanio());
						objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() -  objectList.getObjeto(i).getDanio()); // ataca
						atacado = true; //para que solo ataque una vez
						template.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(),objectList.getObjeto(j).getVida());//modifico tablero
					}

					}
				}
				
			}
		}
		
		*/
		/*
		public void avanzaZombieNormal() { //los zombies avanzan una casilla a la izquierda (si pueden)
			for(int i = 0; i < objectList.ultimaPos(); i++) {
				boolean puede = true;
				if(objectList.getObjeto(i).getLetra() == 'Z' || objectList.getObjeto(i).getLetra() == 'X' || objectList.getObjeto(i).getLetra() == 'W') {
					
					
					if(objectList.getObjeto(i).getLetra() == 'W') {
						puede = false;
						 zom = (Zombie) objectList.getObjeto(i);
						 int r;
						 r = (ciclos - zom.getCiclo()) % 4;
						if(r == 0) {
							puede = true;
						}
					}
					if(objectList.getObjeto(i).getLetra() == 'Z') {
						puede = false;
						 zom = (Zombie) objectList.getObjeto(i);
						 int r;
						 r = (ciclos - zom.getCiclo()) % 2;
						if(r == 0) {
							puede = true;
						}
					}
							if(puede == true) {
				if(objectList.getObjeto(i).getVida() > 0 && template.isEmpty(objectList.getObjeto(i).getX(), objectList.getObjeto(i).getY() -1)) { //si esta vivo y no tiene nada a la izquierda
				template.setBoardVacia(objectList.getObjeto(i).getX(),objectList.getObjeto(i).getY()); //borro del tablero donde estaba antes
				objectList.getObjeto(i).setY(objectList.getObjeto(i).getY() - objectList.getObjeto(i).getVelocidad()); //modifico en la lista de zombies
				template.setBoard(objectList.getObjeto(i).getLetra(), objectList.getObjeto(i).getX(),objectList.getObjeto(i).getY(),objectList.getObjeto(i).getVida());//modifico en tablero
				//template.setBoardVacia(zombielist.zom(i).getX(), zombielist.zom(i).getY()); //borro del tablero donde estaba antes
				}
							}
						
					}
			}
			
		}
		
		*/

			/*
			for(int i = 0; i < zombielist.tamano(); i++) { //ataca a un girasol
				for(int j = 0; j < sunList.ultimaPos(); j++) {
					if(zombielist.zom(i).getResistencia() > 0) {//si esta vivo
						if(zombielist.zom(i).getX() == sunList.sun(j).getX() && zombielist.zom(i).getY() == sunList.sun(j).getY() + 1) { //si esta a su izquierda
							sunList.sun(j).setResistencia(sunList.sun(j).getResistencia() - zombielist.zom(i).getDanio()); //le quita uno de danio en la lista
							template.setBoard('S', sunList.sun(j).getX(), sunList.sun(j).getY(), sunList.sun(j).getResistencia()); //modifico tablero
						}
					}
				}
			}
			*/
		
		/*
		public void atacaCereza() {
			Petacereza cere;
			for(int i = 0; i < objectList.ultimaPos();i++) {
				if(objectList.getObjeto(i).getLetra() == 'C') {
					cere = (Petacereza) objectList.getObjeto(i);

					int resul;
					resul = (ciclos - cere.getCiclo()) % 3;
					if( resul == 0) { //esta mal seguro ese getCiclo
						if( (ciclos - cere.getCiclo() != 0) ) {
						
						for(int j = 0; j < objectList.ultimaPos();j++) {

						if(objectList.getObjeto(i).getX() != 3 && objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX() +1 && objectList.getObjeto(i).getY() == objectList.getObjeto(j).getY()) {//si esta debajo
							objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - objectList.getObjeto(i).getDanio());//le quitas 10 de vida
							template.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero

						}
						 if(objectList.getObjeto(i).getX() != 0 && objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX() - 1 && objectList.getObjeto(i).getY() == objectList.getObjeto(j).getY()) { // si esta arriba
							objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - objectList.getObjeto(i).getDanio());//le quitas 10 de vida
							template.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero

						}
						 if(objectList.getObjeto(i).getY() != 7 && objectList.getObjeto(i).getY() == objectList.getObjeto(j).getY() + 1 && objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX()) { // si esta a la derecha
							objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - objectList.getObjeto(i).getDanio());//le quitas 10 de vida
							template.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero

						}
						 if(objectList.getObjeto(i).getY() != 0 && objectList.getObjeto(i).getY() == objectList.getObjeto(j).getY() - 1 &&  objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX()) { // si esta a la izquierda
							objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - objectList.getObjeto(i).getDanio());//le quitas 10 de vida
							template.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero

						}
						 if(objectList.getObjeto(i).getX() != 0 && objectList.getObjeto(i).getY() != 7 && objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX() - 1 &&  objectList.getObjeto(i).getY() == objectList.getObjeto(j).getY() + 1) { // si esta a la arriba derecha
							objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - objectList.getObjeto(i).getDanio());//le quitas 10 de vida
							template.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero
						}
						 if(objectList.getObjeto(i).getX() != 0 && objectList.getObjeto(i).getY() != 0 && objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX() - 1 &&  objectList.getObjeto(i).getY() == objectList.getObjeto(j).getY()-1) { // si esta a la arriba izquierda
							objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - objectList.getObjeto(i).getDanio());//le quitas 10 de vida
							template.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero
						}
						 if(objectList.getObjeto(i).getX() != 3 && objectList.getObjeto(i).getY() != 7 && objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX() + 1 &&  objectList.getObjeto(i).getY() == objectList.getObjeto(j).getY()+1) { // si esta a la abajo derecha
							objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - objectList.getObjeto(i).getDanio());//le quitas 10 de vida
							template.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero
						}
						 if(objectList.getObjeto(i).getX() != 3 && objectList.getObjeto(i).getY() != 0 && objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX() + 1 &&  objectList.getObjeto(i).getY() == objectList.getObjeto(j).getY()-1) { // si esta a la abajo izquierda
							objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - objectList.getObjeto(i).getDanio());//le quitas 10 de vida
							template.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero
						}
						}
						objectList.getObjeto(i).setVida(0);//la planta muere despues de explotar
						template.setBoardVacia(objectList.getObjeto(i).getX(), objectList.getObjeto(i).getY());//lo borro del tablero

						}
					}
				}
			}
		}
		*/
	//	public void muerte() {
			/*
			for(int i = 0; i < zombielist.tamano(); i++) {
				if(zombielist.zom(i).getResistencia() == 0) {
					template.setBoardVacia(zombielist.zom(i).getX(), zombielist.zom(i).getY()); //borro de tablero
					zombielist.borrar(i); //borro de la lista
					i--;
				}
			}
			*/

			/*
			for(int i = 0; i < sunList.ultimaPos(); i++) {
				if(sunList.sun(i).getResistencia() == 0) {
					template.setBoardVacia(sunList.sun(i).getX(), sunList.sun(i).getY()); //borro de tablero
					sunList.borrar(i); //borro de la lista
					i--;
				}
			}
			*/
		
		
		
		
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		

