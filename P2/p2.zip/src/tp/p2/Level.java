package tp.p2;

	
	
	public enum Level{
		EASY,
		HARD,
		INSANE
	}

	
