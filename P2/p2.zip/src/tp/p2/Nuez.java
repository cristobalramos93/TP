package tp.p2;

import commands.GameObjectList;
import commands.Plants;

public class Nuez extends Plants {

	
	
	public Nuez() {
		super("N","[N]uez: Cost: 50 suncoins Harm: 0");
	}
	public Nuez(int x, int y, int coste, int resistencia, int danio, int frecuencia,char letra,int ciclo ) {
		super(x,y,resistencia,coste,frecuencia,danio,letra,ciclo);

	}
	GameObjectList objectList;
	//GamePrinterTemplate template;
	public void ataca(GameObjectList objectList,BoardPrinter printer,Game game) {
		
	}
	
}
