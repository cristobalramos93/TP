package tp.p2;

import commands.GameObject;
import commands.GameObjectList;
import commands.Zombies;

public class ZombieLento extends Zombies {

	//private int ciclo;
	
	public ZombieLento(int x, int y, int resistencia, int danio,int velocidad,char letra,int ciclo) {
		super(x,y,resistencia,danio,velocidad,letra,ciclo);
		//this.danio = danio;
		//this.velocidad = velocidad;
		//this.ciclo = ciclo;
	}
	
	
	public ZombieLento() {
		super("W","[Z]ombie caracubo: speed: 4 Harm: 1 Life: 8");
	}
	
	
	
	public void avanza(Game game,BoardPrinter printer,GameObjectList list) {
		
		int r;
		 r = (game.getCiclos() - this.getCiclo()) % this.getFrecuencia();
		if(r == 0) {
			if(this.getVida() > 0 && printer.isEmpty(this.getX(), this.getY() -1,list)) { //si esta vivo y no tiene nada a la izquierda
				//printer.setBoardVacia(this.getX(),this.getY()); //borro del tablero donde estaba antes
				this.setY(this.getY() - 1); //modifico en la lista de zombies
			//	printer.setBoard(this.getLetra(), this.getX(),this.getY(),this.getVida());//modifico en tablero
				//template.setBoardVacia(zombielist.zom(i).getX(), zombielist.zom(i).getY()); //borro del tablero donde estaba antes
				}
			}				
		}
	
}
