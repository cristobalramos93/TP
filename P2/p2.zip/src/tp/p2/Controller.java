package tp.p2;

import java.util.Random;

import java.util.Scanner;

import commands.Command;
import commands.CommandParser;

public class Controller {
	private boolean perder = false;
	private boolean ganar = false;
	private int quedan;
	private Game game;
	private Scanner in;
	PlantsVsZombies pz;
	//GamePrinterTemplate template;
	BoardPrinter printer;
	Level level;
	public Controller(Game game, Scanner in) {
		this.game = game;
		this.in = in;
	}

	public void run() {
		//System.out.println("Welcome to Zombies" + '\n');
		
		/*
		System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
		System.out.println("Number of cycles: " + (game.getCiclos()-1));
		System.out.println("Sun coins: " + game.suncoin.getSuncoins());
		quedan = game.zombiesQuedan();
		System.out.println("Remaining zombies: " + quedan); //zombies que quedan por salir+ 
				
		
		
		System.out.println(game.template.toString());
		*/
		System.out.println(game.getPrinter().toString(game,game.getObjectList()));
		
		String[] words;
		System.out.println("Command > ");
		words = in.nextLine().split(" ");
		Command comando = CommandParser.parseCommand(words, this,game.getObjectList(),game);
		
		
		
		
		while(!game.isFin()){ 
			
				if(comando != null) {
					comando.execute(game, this);
					game.hasGanado();
					game.hasPerdido();
					/*
					if(game.isFin()) {//si has perdido
						System.out.println(game.template.toString());

					}
	*/
					if(!words[0].equalsIgnoreCase("exit") && !game.isFin()) {
						if(comando.isNoPrintGameState()) {
							//System.out.println(game.template.toString());
							System.out.println(game.getPrinter().toString(game,game.getObjectList()));
						}
					System.out.print("Command > ");
					words = in.nextLine().split(" ");
					comando = CommandParser.parseCommand(words, this,game.getObjectList(),game);
					}
				}
				else{
					System.out.println("Comando nulo");
					System.out.print("Command > ");
					words = in.nextLine().split(" ");
					comando = CommandParser.parseCommand(words, this,game.getObjectList(),game);
	
				}
			

		}
		
		/*
		
		while( !words[0].equalsIgnoreCase("e") && !perder && !ganar) {
			if(  words.length == 4 && words[0].equalsIgnoreCase("a") && (words[1].equalsIgnoreCase("p") || words[1].equalsIgnoreCase("s") ||words[1].equalsIgnoreCase("peashooter") || words[1].equalsIgnoreCase("sunflower") ) ){
				this.game.userCommand(Integer.parseInt(words[2]),Integer.parseInt(words[3]),words[1]);
				perder = game.hasPerdido();
				ganar = game.hasGanado();
				
			}
			
			else if(words[0].equalsIgnoreCase("r") && words.length == 1) {
				game = new Game(new SunflowerList(),new PeashooterList(),new ZombieList(),1,PlantsVsZombies.getSeed(),game.getLevel(),new SuncoinManager(pz.getSoles()),new GamePrinterTemplate(4,8));
				System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
				System.out.println("Number of cycles: " + (game.getCiclos()-1));
				System.out.println("Sun coins: " + game.suncoin.getSuncoins());
				quedan = game.zombiesQuedan();
				System.out.println("Remaining zombies: " + quedan); //zombies que quedan por salir+ 
						
				
				
				System.out.println(game.template.toString());
				//run();
			}
			else if(words[0].equalsIgnoreCase("l") && words.length == 1) {
				mostrarList();
			}
			else if((words[0].equalsIgnoreCase("") || words[0].equalsIgnoreCase("n")) && words.length == 1) {
				game.update();
				perder = game.hasPerdido();
				ganar = game.hasGanado();
			}

			else if(words[0].equalsIgnoreCase("h") && words.length == 1) {
				mostrarHelp();
			}else {
				System.out.println("Comando no valido. Escribe help para ver la ayuda");
			}
		
			if(!ganar && !perder) {
			System.out.println("Command > ");
			words = in.nextLine().split(" ");
			}
		

		}
		if(words[0].equalsIgnoreCase("e")) {
			System.out.println("Has pulsado exit. Game Over!");
		}
		else if(perder) {
			System.out.println("Has perdido!");
		}
		else if(ganar) System.out.println("Has ganado!");
	}
	
	
	private void mostrarHelp() {
		System.out.println("Add <plant> <x> <y>: Adds a plant in position x, y");
		System.out.println("List: Prints the list of available plants.");
		System.out.println("Reset: Starts a new game.");
		System.out.println("Help: Prints this help message.");
		System.out.println("Exit: Terminates the program.");
		System.out.println("[none]: Skips cycle.");
	}
	
	private void mostrarList() {
		System.out.println("[S]unflower: Cost: 20 suncoins  Harm: 0");
		System.out.println("[P]eashooter: Cost: 50 suncoins  Harm: 1");
		//System.out.println("[S]unflower: Cost:" + game.sun.getCoste()+" suncoins  Harm: " + game.sun.getDanio());
		//System.out.println("[P]eashooter: Cost:" + game.pea.getCoste()+" suncoins  Harm: " + game.pea.getDanio());
	}
		*/
}
}
