package tp.p2;

import commands.GameObjectList;

public interface PintarTablero {

	
	
}
