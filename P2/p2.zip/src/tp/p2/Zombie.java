package tp.p2;

import commands.GameObject;
import commands.GameObjectList;
import commands.Zombies;

public class Zombie extends Zombies {

	//private int ciclo;
	
	public Zombie(int x, int y, int resistencia, int danio,int velocidad,char letra,int ciclo) {
		super(x,y,resistencia,danio,velocidad,letra,ciclo);
		//this.danio = danio;
		//this.velocidad = velocidad;
		//this.ciclo = ciclo;
	}
	
	
	public Zombie() {
		super("Z","[Z]ombie comun: speed: 2 Harm: 1 Life: 5  ");
	}
	
	public void avanza(Game game,BoardPrinter printer,GameObjectList list) {
					
		int r;
		 r = (game.getCiclos() - this.getCiclo()) % this.getFrecuencia();
		if(r == 0) {
			if(this.getVida() > 0 && printer.isEmpty(this.getX(), this.getY() -1,list)) { //si esta vivo y no tiene nada a la izquierda
				//printer.setBoardVacia(this.getX(),this.getY()); //borro del tablero donde estaba antes
				this.setY(this.getY() - 1); //modifico en la lista de zombies
				//printer.setBoard(this.getLetra(), this.getX(),this.getY(),this.getVida());//modifico en tablero
				//template.setBoardVacia(zombielist.zom(i).getX(), zombielist.zom(i).getY()); //borro del tablero donde estaba antes
				}
			}				
		}
				
							
/*
public int getCiclo() {
		return ciclo;
	}

	public void setCiclo(int ciclo) {
		this.ciclo = ciclo;
	}

	/*
	public int getResistencia() {
		return resistencia;
	}
*/
	/*
	private int danio;
	private int velocidad;
	Game game;
	/*
	public int getX() {
		return x;
	}
*/
/*
	public int getVelocidad() {
		return velocidad;
	}

/*
	public int getY() {
		return y;
	}


	public void setX(int x) {
		this.x = x;
	}


	public void setY(int y) {
		this.y = y;
	}


	public void setResistencia(int resistencia) {
		this.resistencia = resistencia;
	}
*/
/*
	public int getDanio() {
		return danio;
	}


	public void setDanio(int danio) {
		this.danio = danio;
	}
	/*
	ZombieList zombielist;
	GamePrinterTemplate template;
	GameObjectList objectList;
	*/
	/*
public void update() {
		
		//sumaSoles();
		//ataca();
		atacaZombie();
		avanza();
		//muerte();
		//numZombies = ZombieManager.computerAction(level,rand,template,zombielist,numZombies,zom,quedan); // aparicion de zombie y devuelvo el contador de zombies
		//ciclos++;
		//System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
		//System.out.println("Number of cycles: " + (ciclos-1));
		//System.out.println("Sun coins: " + suncoin.getSuncoins());
		//quedan = zombiesQuedan();
		//System.out.println("Remaining zombies: " + quedan); //zombies que quedan por salir
		
		//System.out.println(template.toString());
	}
	*/
	/*
	public void avanza() { //los zombies avanzan una casilla a la izquierda (si pueden)
		for(int i = 0; i < zombielist.tamano(); i++) {
			if(zombielist.zom(i).getResistencia() > 0 && template.isEmpty(zombielist.zom(i).getX(), zombielist.zom(i).getY() -1)) { //si esta vivo y no tiene nada a la izquierda
			template.setBoardVacia(zombielist.zom(i).getX(), zombielist.zom(i).getY()); //borro del tablero donde estaba antes
			zombielist.zom(i).setY(zombielist.zom(i).getY() - zombielist.zom(i).getVelocidad()); //modifico en la lista de zombies
			template.setBoard('Z', zombielist.zom(i).getX(), zombielist.zom(i).getY(), zombielist.zom(i).getResistencia());//modifico en tablero
			//template.setBoardVacia(zombielist.zom(i).getX(), zombielist.zom(i).getY()); //borro del tablero donde estaba antes
			}
		}
	}

	
	public void atacaZombie() { // de la lista de guisantes, busca si hay zombies en su fila de la lista de zombies
		
		for(int i = 0; i < zombielist.tamano(); i++) { //ataca a guisante
			for(int j = 0; j < objectList.ultimaPos(); j++) {
				if(zombielist.zom(i).getResistencia() > 0) { //si esta vivo
					if(zombielist.zom(i).getX() == objectList.getObjeto(j).getX() && zombielist.zom(i).getY() == objectList.getObjeto(j).getY() + 1) { //si esta a su izquierda
						objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - zombielist.zom(i).getDanio()); //le quita uno de danio en la lista
						template.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero

					}
				}
			}
		}


}
*/
}
