package tp.p2;

import commands.GameObjectList;

public class ReleasePrinter extends BoardPrinter implements PintarTablero {

	public ReleasePrinter(int dimX, int dimY,GameObjectList objectList,Game game) {
		super(dimX, dimY,objectList,game);
		// TODO Auto-generated constructor stub
	}


	
	public void encodeGame() {
		board = new String[dimX][dimY];
		for(int i = 0; i < dimX; i++) {
			for(int j = 0; j < dimY; j++) {

				board[i][j] =  space;
				// TODO Fill the board with simulation objects
			}
		}


	}
	
	public void pintarTablero(GameObjectList objectList,Game game) {

		for(int i = 0; i < objectList.ultimaPos(); i++) {
			setBoard1(objectList.getObjeto(i).getLetra(),objectList.getObjeto(i).getX() , objectList.getObjeto(i).getY(), objectList.getObjeto(i).getVida());
		}
	}
	
	public String toString(Game game,GameObjectList objectList) {
		mostrarMensaje(game);
		encodeGame();
		pintarTablero(objectList,game);
		int cellSize = 7;
		int marginSize = 2;
		String vDelimiter = "|";
		String hDelimiter = "-";
		
		String rowDelimiter = GamePrinter.repeat(hDelimiter, (dimY * (cellSize + 1)) - 1);
		String margin = GamePrinter.repeat(space, marginSize);
		String lineDelimiter = String.format("%n%s%s%n", margin + space, rowDelimiter);
		
		StringBuilder str = new StringBuilder();
		
		str.append(lineDelimiter);
		
		for(int i=0; i<dimX; i++) {
				str.append(margin).append(vDelimiter);
				for (int j=0; j<dimY; j++) {
					str.append( GamePrinter.centre(board[i][j], cellSize)).append(vDelimiter);
				}
				str.append(lineDelimiter);
		}
		return str.toString();
	}
	
	public void mostrarMensaje(Game game) {
		int quedan;
		System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
		System.out.println("Number of cycles: " + (game.getCiclos()-1));
		System.out.println("Sun coins: " + game.suncoin.getSuncoins());
		quedan = game.zombiesQuedan();
		System.out.println("Remaining zombies: " + quedan);  //zombies que quedan por salir
	}

	public void setBoard1(char c, int x, int y, int res) {
		this.board[x][y] = c + " [" + res + "]" ;
	}
	

}
