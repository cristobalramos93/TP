package tp.p2;

import commands.GameObject;
import commands.GameObjectList;
import commands.Plants;

public class Peashooter extends Plants {
	
	
	/*
	private int x;
	private int y;
	private int coste;
	private int resistencia;
	private int danio;
	private int frecuencia;
	//private int alcance;
	*/
	public Peashooter(){
		super("P","[P]eashooter: Cost: 50 suncoins Harm: 1 ");
	}
	
	public Peashooter(int x, int y, int coste, int resistencia, int danio, int frecuencia,char letra,int ciclo) {
		super(x,y,resistencia,coste,frecuencia,danio,letra,ciclo);
		//this.x = x;
		//this.y = y;
		//this.coste = coste;
		//this.resistencia = resistencia;
		//this.danio = danio;
		//this.frecuencia = frecuencia;
	}


	Game game;
	GameObjectList objectList;
	//GamePrinterTemplate template;
	
	
	public void ataca(GameObjectList objectList,BoardPrinter printer,Game game) { // de la lista de guisantes, busca si hay zombies en su fila de la lista de zombies
		//for(int i = 0; i < objectList.ultimaPos(); i++) {
			//if(objectList.getObjeto(i).getLetra() == 'P') { //si de la lista, es un lanzaguisantes
			boolean atacado = false;
			for(int j = 0; j < objectList.ultimaPos(); j++) {
				//Plants planta2;
				//planta2 = (Plants) objectList.getObjeto(i);
				if((objectList.getObjeto(j).getLetra() == 'Z'|| objectList.getObjeto(j).getLetra() == 'W' || objectList.getObjeto(j).getLetra() == 'X' ) && this.getX() == objectList.getObjeto(j).getX() && objectList.getObjeto(j).getVida() > 0 && !atacado) { //si esta en su fila y esta vivo y si es un zombie
					//System.out.println(planta2.getDanio());
					objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() -  this.getDanio()); // ataca
					atacado = true; //para que solo ataque una vez
					//printer.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(),objectList.getObjeto(j).getVida());//modifico tablero
			//	}

				//}
			}
			
		}
	}
	
	/*
public void update() {
		
		//sumaSoles();
		ataca();
		//atacaZombie();
		//avanza();
		//muerte();
		//numZombies = ZombieManager.computerAction(level,rand,template,zombielist,numZombies,zom,quedan); // aparicion de zombie y devuelvo el contador de zombies
		//ciclos++;
		//System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
		//System.out.println("Number of cycles: " + (ciclos-1));
		//System.out.println("Sun coins: " + suncoin.getSuncoins());
		//quedan = zombiesQuedan();
		//System.out.println("Remaining zombies: " + quedan); //zombies que quedan por salir
		
		//System.out.println(template.toString());
	}

public void ataca() { // de la lista de guisantes, busca si hay zombies en su fila de la lista de zombies
	for(int i = 0; i < objectList.ultimaPos(); i++) {
		if(objectList.getObjeto(i).getLetra() == 'p') { //si de la lista, es un lanzaguisantes
		boolean atacado = false;
		for(int j = 0; j < zombielist.tamano(); j++) {
			if( objectList.getObjeto(i).getX() == zombielist.zom(j).getX() && zombielist.zom(j).getResistencia() > 0 && !atacado) { //si esta en su fila y esta vivo
				zombielist.zom(j).setResistencia(zombielist.zom(j).getResistencia() - objectList.getObjeto(i).getDanio()); // ataca
				atacado = true; //para que solo ataque una vez
				template.setBoard('Z', zombielist.zom(j).getX(), zombielist.zom(j).getY(), zombielist.zom(j).getResistencia());//modifico tablero
			}

			}
		}
		
	}
}
*/
/*
	public int getResistencia() {
		return resistencia;
	}

	public int getCoste() {
		return coste;
	}

	public void setCoste(int coste) {
		this.coste = coste;
	}
/*
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
*/
	/*
	public int getDanio() {
		return danio;
	}

	public void setDanio(int danio) {
		this.danio = danio;
	}

	public void setResistencia(int resistencia) {
		this.resistencia = resistencia;
	}


	
*/
	

}
