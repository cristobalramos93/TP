package tp.p2;

import java.util.Random;
import java.util.Scanner;

import commands.GameObjectList;


public class PlantsVsZombies {
	private static Random seed;
	static int semilla;
	final static int soles = 50;
	static GameObjectList objectList;
	
	public static int getSoles() {
		return soles;
	}

	public static void main(String[] args) {
		Game game = null;
		objectList = new GameObjectList();
		Level level = null;
		if(args.length == 1) {
			semilla = new Random().nextInt(1000);
			seed = new Random(semilla);
			if(args[0].equalsIgnoreCase("easy")) { 
				game = new Game(1,seed,level.EASY,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,objectList,new ReleasePrinter(4,8,objectList,game));
			}
			else if(args[0].equalsIgnoreCase("hard")) { 
				game = new Game(1,seed,level.HARD,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,new GameObjectList(),new ReleasePrinter(4,8,objectList,game));
			}
			else game = new Game(1,seed,level.INSANE,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,new GameObjectList(),new ReleasePrinter(4,8,objectList,game));

		
		}
		
		if(args.length == 2) {
			semilla = Integer.parseInt(args[1]);
			seed = new Random(semilla);
			if(args[0].equalsIgnoreCase("easy")) { 
				game = new Game(1,seed,level.EASY,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,new GameObjectList(),new ReleasePrinter(4,8,objectList,game));
			}
			else if(args[0].equalsIgnoreCase("hard")) { 
				game = new Game(1,seed,level.HARD,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,new GameObjectList(),new ReleasePrinter(4,8,objectList,game));
			}
			else game = new Game(1,seed,level.INSANE,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,new GameObjectList(),new ReleasePrinter(4,8,objectList,game));

		}
		
		
		
		
		Controller controlador = new Controller(game, new Scanner(System.in));
		controlador.run();
	}

	public static Random getSeed() {
		return seed;
	}
	
	public static int getSemilla() {
		return semilla;
	}
}
