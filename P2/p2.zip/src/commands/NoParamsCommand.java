package commands;

import tp.p2.Controller;
import tp.p2.Game;

public abstract class NoParamsCommand extends Command{
	

	public NoParamsCommand(String commandInfo, String helpInfo) {
		super(commandInfo, helpInfo);
	}

	public Command parse(String[] commandWords, Controller controller,GameObjectList objectList,Game game) {
		
			if(commandWords[0].equalsIgnoreCase(commandName)) {
				return this;
			}
			else return null;
		
		
	}
	
	
	public abstract void execute(Game game, Controller controller);

}
