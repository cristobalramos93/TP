package commands;

import java.util.Random;


import tp.p2.BoardPrinter;
import tp.p2.Controller;
import tp.p2.DebugPrinter;
import tp.p2.Game;
//import tp.p2.GamePrinterTemplate;
import tp.p2.Level;
import tp.p2.ReleasePrinter;
import tp.p2.SuncoinManager;

public class PrintModeCommand extends NoParamsCommand{

		BoardPrinter printer;
		
	public PrintModeCommand() {
		super("PrintMode", "Change print mode [Release|Debug]");
		// TODO Auto-generated constructor stub
	}

	public PrintModeCommand( BoardPrinter printer) {
		super("PrintMode", "Change print mode [Release|Debug]");
		this.printer = printer;
	}

	public Command parse(String[] commandWords, Controller controller,GameObjectList objectList,Game game){
		if (commandWords[0].equalsIgnoreCase("PrintMode")){
			
			if(commandWords.length == 2 && commandWords[1].equalsIgnoreCase("Release") || commandWords[1].equalsIgnoreCase("Debug")){
				
				if(commandWords[1].equalsIgnoreCase("Release")) {
					System.out.println("You have chosen Release Mode");
					return new PrintModeCommand(new ReleasePrinter(4, 8,objectList, game));
				}
				else {
					return new PrintModeCommand(new DebugPrinter(0, objectList.ultimaPos(),objectList,game));
				}
			}
			
			else {
				if(commandWords.length != 2)System.out.println("solo se pueden 2 palabras");
				else System.out.println("la segunda tiene que ser s , p, c o n");
				return null;
			}
		}
		
		else {
			//System.out.println("Comando no valido. Escribe help para ver la ayuda");
			return null;
		}
	
	}
	
	public void execute(Game game, Controller controller){
		game.cambioDeTablero(printer);
		this.setNoPrintGameState(true);

		//public Game(int ciclos,Random seed,Level level,SuncoinManager suncoin,GamePrinterTemplate template,GameObjectList objectList,BoardPrinter printer) {
		
	}
}
