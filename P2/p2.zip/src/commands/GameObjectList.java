package commands;


public class GameObjectList {

	private GameObject[] GameObjectList;

	public GameObjectList(){
		GameObjectList=new GameObject[0];
	}
	
	
	public GameObject[] getGameObjectList() {
		return GameObjectList;
	}

	public void setGameObjectListList(GameObject[] gameObjectList) {
		GameObjectList = gameObjectList;
	}

	
	public int ultimaPos() {
		
		return GameObjectList.length;
	}
	
	public GameObject getObjeto(int i) { //devuelve un guisante de la lista
		return GameObjectList[i];
	}

	
	public void aniadir(GameObject pea) {
		GameObject[] aux=GameObjectList;
		GameObjectList=new GameObject[GameObjectList.length+1];
		for(int i=0; i<aux.length;i++) {
			GameObjectList[i]=aux[i];
		}
		GameObjectList[GameObjectList.length-1] = pea;
	}
	
	
	public void borrar(int i) { //muerte de un guisante

		if(i == GameObjectList.length-1) { //si es el ultimo se borra
			GameObjectList[i] = null;
		}
		else {
			for(int n = i ;  n < GameObjectList.length - 1; n++ ) {
				GameObjectList[n] = GameObjectList[n+1];
			}
			GameObjectList[GameObjectList.length-1] = null;
		}
		

		GameObject[] aux=GameObjectList; //utilizamos un auxiliar para cambiar el .length
		GameObjectList=new GameObject[GameObjectList.length-1];
		for(int j=0; j<aux.length -1;j++) {
			GameObjectList[j]=aux[j];
		}
		
	}
}

