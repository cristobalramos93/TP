package commands;

import tp.p2.Controller;
import tp.p2.Game;

public class ListCommand extends NoParamsCommand{
	
	public ListCommand() {
		super("list", " print the list of available plants");
	}
	

	

	public void execute(Game game, Controller controller){//llama a commandHelp que llama a todos los mensajes de la subclase
		String m;
		PlantFactory fac = null;
		m = fac.listOfAvilablePlants();
		System.out.println(m);
		//System.out.println("holaaaa");
		this.setNoPrintGameState(false);

	}
}

