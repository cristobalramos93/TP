package commands;

import tp.p2.BoardPrinter;

import tp.p2.Game;
//import tp.p2.GamePrinterTemplate;

public abstract class Zombies extends GameObject {

	
	private int danio;
	//private int frecuencia;
	//private int ciclo;
	public Zombies(int x, int y, int vida,int danio,int frecuencia,char letra,int ciclo) {
		super(x, y, vida,letra,ciclo,frecuencia);
		this.danio = danio;
		//this.frecuencia = frecuencia;
		//this.ciclo = ciclo;
		//this.ciclo = ciclo;
		//this.letra = letra;
	}
	
	
	public Zombies(String nombre,String info) {
		// TODO Auto-generated constructor stub
		super(nombre,info);
	}
	
	
	public abstract void avanza(Game game,BoardPrinter printer,GameObjectList list);


	public int getDanio() {
		return danio;
	}


	public void setDanio(int danio) {
		this.danio = danio;
	}

/*
	public int getVelocidad() {
		return frecuencia;
	}


	public void setVelocidad(int frecuencia) {
		this.frecuencia = frecuencia;
	}

/*
	public int getCiclo() {
		return ciclo;
	}
*/
/*
	public void setCiclo(int ciclo) {
		this.ciclo = ciclo;
	}
	*/
}
