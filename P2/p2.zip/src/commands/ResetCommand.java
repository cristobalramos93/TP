package commands;

import tp.p2.Controller;
import tp.p2.Game;

public class ResetCommand extends NoParamsCommand{

	public ResetCommand() {
		super("r", "start a new game.");
	}



	public void execute(Game game, Controller controller){
		 game.reset();
		this.setNoPrintGameState(true);


	}
}
