package commands;

import tp.p2.Controller;
import tp.p2.Game;

public class ListZombies extends NoParamsCommand{
	
	public ListZombies() {
		super("zombielist", " print the list of available zombies");
	}
	

	

	public void execute(Game game, Controller controller){//llama a commandHelp que llama a todos los mensajes de la subclase
		String m;
		ZombiesFactory fac = null;
		m = fac.listOfAvilableZombies();
		System.out.println(m);
		//System.out.println("holaaaa");
		this.setNoPrintGameState(false);

	}
}
