package commands;

import tp.p2.Controller;
import tp.p2.Game;

public class UpdateCommand extends NoParamsCommand{
	
	public UpdateCommand() {
		super("", " pasa turno");
	}
	

	

	public void execute(Game game, Controller controller){//llama a commandHelp que llama a todos los mensajes de la subclase
		game.update();
		this.setNoPrintGameState(true);

	}
}

