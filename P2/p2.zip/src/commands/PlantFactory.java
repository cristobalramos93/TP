package commands;

import tp.p2.Game;
import tp.p2.Nuez;
import tp.p2.Peashooter;
import tp.p2.Petacereza;
import tp.p2.Sunflower;

public class PlantFactory {
	 //  Game game;

		private static Plants[] availablePlants = { new Sunflower(), new Peashooter(), new Petacereza(), new Nuez() };
		
		 static Plants planta;
		
		//	public Plants(int x, int y, int vida,int coste,int frecuencia,int danio,char letra,int ciclo) {

		public static  Plants getPlant(String plantName,int x, int y,  Game game){
			boolean encontrado = false;
			int n = 0;
			while(n < availablePlants.length && !encontrado){
						if(plantName.equalsIgnoreCase( availablePlants[0].getNombre())){// == availablePlants[0].getNombre()) {
							planta = new Sunflower(x,y,20,1,0,3,game.getCiclos(),'S');
							//	public Sunflower(int x, int y, int coste, int resistencia, int danio, int frecuencia, int ciclo,char letra ) {

						}
						else if(plantName.equalsIgnoreCase( availablePlants[1].getNombre())) {
							planta = new Peashooter(x,y,50,3,1,1,'P',game.getCiclos());
							//public Peashooter(int x, int y, int coste, int resistencia, int danio, int frecuencia,char letra,int ciclo) {

						}
						else if(plantName.equalsIgnoreCase( availablePlants[2].getNombre())) {
							planta = new Petacereza(x,y,50,2,10,2,game.getCiclos(),'C');
							//	public Petacereza(int x, int y, int coste, int resistencia, int danio, int frecuencia, int ciclo,char letra ) {

						}
						else if(plantName.equalsIgnoreCase( availablePlants[3].getNombre())) {
						planta = new Nuez(x,y,50,10,0,0,'N',game.getCiclos());
						//	public Nuez(int x, int y, int coste, int resistencia, int danio, int frecuencia,char letra,int ciclo ) {

						}
					n++;
					if(planta != null){
						encontrado = true;
					}	
			}
			return planta;
		}
		//public static String listOfAvilablePlants() { ... }
		
		public static String listOfAvilablePlants() { //almacena en mensaje los textos de cada subclase
			String mensaje = "";
			mensaje = "The available plant are:" + '\n';
			for(int n = 0; n < availablePlants.length; n++) {
				mensaje += availablePlants[n].getInfo() + '\n';
			}
			return mensaje;

		}
}
