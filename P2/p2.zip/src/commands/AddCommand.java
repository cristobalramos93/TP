package commands;

import tp.p2.Controller;
import tp.p2.Game;

public class AddCommand extends NoParamsCommand{
	private int x;
	private int y;
	private String valor;
	
	public AddCommand() {
		super("a", " add flower");
	}
	
	
	AddCommand(int x, int y, String valor){
		super("add", " add flower");
		this.x = x;
		this.y = y;
		this.valor = valor;
	}
	
	
	
	public Command parse(String[] commandWords, Controller controller,GameObjectList objectList,Game game){
		if (commandWords[0].equalsIgnoreCase("a") && commandWords.length == 4 ){
			
			if(commandWords.length == 4 && commandWords[1].equalsIgnoreCase("s") || commandWords[1].equalsIgnoreCase("p") || commandWords[1].equalsIgnoreCase("c")|| commandWords[1].equalsIgnoreCase("n") ){
				return new AddCommand(Integer.parseInt(commandWords[2]),Integer.parseInt(commandWords[3]),commandWords[1]);
			}
			
			else {
				if(commandWords.length != 4)System.out.println("solo se pueden 4 digitos");
				else System.out.println("la segunda tiene que ser s , p, c o n");
				return null;
			}
		}
		
		else {
			//System.out.println("Comando no valido. Escribe help para ver la ayuda");
			return null;
		}
	
	}
	
	

	public void execute(Game game, Controller controller){//llama a commandHelp que llama a todos los mensajes de la subclase
		boolean mostrar;
		Plants plants = PlantFactory.getPlant(this.valor, x,  y,game);
		if(plants!= null) {
		mostrar = game.addPlantToGame(x, y, plants);
		if(mostrar == true)	this.setNoPrintGameState(true);
		else this.setNoPrintGameState(false);


		}
		//update();
	//	game.userCommand(x, y, valor);
		
	}
}
