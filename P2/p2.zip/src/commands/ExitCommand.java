package commands;

import tp.p2.Controller;
import tp.p2.Game;

public class ExitCommand extends NoParamsCommand{

	public ExitCommand() {
		super("exit", "terminate the program.");
	}

	
	

	public void execute(Game game, Controller controller){
		game.setFin(true);
		System.out.println("Has abandonado");
		this.setNoPrintGameState(false);

	}




	





}
