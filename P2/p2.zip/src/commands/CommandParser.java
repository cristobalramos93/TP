package commands;

import tp.p2.Controller;

import tp.p2.Game;

public class CommandParser {
	
	private static Command[] availableCommands = { new HelpCommand(), new ResetCommand(), new ExitCommand(), new AddCommand(), new ListCommand(),new UpdateCommand(),new ListZombies(),new PrintModeCommand()};
	
	public static Command parseCommand(String[] commandWords, Controller controller,GameObjectList objectList,Game game){
		Command com = null;
		boolean encontrado = false;
		int n = 0;
		while(n < availableCommands.length && !encontrado){
				com=availableCommands[n].parse(commandWords, controller,objectList,game);
				n++;
				if(com != null){
					encontrado = true;
				}	
		}
		return com;
	}
	
	
	
	public static String commandHelp() { //almacena en mensaje los textos de cada subclase
		String mensaje = "";
		mensaje = "The available commands are:";
		mensaje += '\n';
		for(int n = 0; n < availableCommands.length; n++) {
			
			mensaje += "	" + availableCommands[n].helpText();
			mensaje += '\n';
		}
		return mensaje;

	}
}
