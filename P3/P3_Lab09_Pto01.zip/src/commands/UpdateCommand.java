package commands;

import tp.p3.Game;

public class UpdateCommand extends NoParamsCommand{
	
	public UpdateCommand() {
		super("", " pasa turno");
	}
	

	

	public boolean execute(Game game){//llama a commandHelp que llama a todos los mensajes de la subclase
		game.update();
		this.setNoPrintGameState(true);
		return true;
	}
}

