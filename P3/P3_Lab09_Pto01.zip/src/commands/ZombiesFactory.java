package commands;

import java.util.Random;

import tp.p3.BoardPrinter;
import tp.p3.Game;
import tp.p3.Level;
import tp.p3.Zombie;
import tp.p3.ZombieDeportista;
import tp.p3.ZombieLento;

public class ZombiesFactory {
	 //  Game game;

		private static Zombies[] availableZombies = { new Zombie(), new ZombieDeportista(),new ZombieLento() };
		
		 static Zombies zom;
		
		
		public static  int getZombie(Level level,Random rand, BoardPrinter printer,int numZombies,int quedan, Game game){
			if(quedan != 0) {
				boolean existe = false;
				int x = rand.nextInt(4);
				int probabilidad = rand.nextInt(9);
				int y =7;
				if(level == Level.EASY) {
					if(probabilidad == 0) { // 1 entre 10
						while(!existe) {
							if(printer.isEmpty(x, y,game.getObjectList())) {
								existe = true;
							}
							else {
								 x = rand.nextInt(4);
							}
						}
						int z = rand.nextInt(3);
						//public Zombies(int x, int y, int vida,int danio,int frecuencia,char letra,int ciclo) {

						 
						 if(z == 0) {
						zom = new Zombie(x,y,5,1,2,'Z',game.getCiclos());
						 }

						 else if(z == 1) zom = new ZombieLento(x,y,8,1,4,'W',game.getCiclos());
						 else zom = new ZombieDeportista(x,y,2,1,1,'X',game.getCiclos());
						//zombielist.aniadir(zom);
						game.nuevoZombie(zom);
						/*
						template.setBoard('Z', x, y,zom.getResistencia() );
						*/

						numZombies++;
						
					}
				}
				else if(level == Level.HARD) {
					if(probabilidad == 1 || probabilidad == 2 || probabilidad == 0 || probabilidad == 3 || probabilidad == 4) { //1 entre 2
						while(!existe) {
							if(printer.isEmpty(x, y,game.getObjectList())) {
								existe = true;
							}
							else {
								 x = rand.nextInt(4);
							}
						}
						int z = rand.nextInt(3);
						 
						 
						 if(z == 0) {
						zom = new Zombie(x,y,5,1,2,'Z',game.getCiclos());
						 }
						 else if(z == 1) zom = new ZombieLento(x,y,8,1,4,'W',game.getCiclos());
						 else zom = new ZombieDeportista(x,y,2,1,1,'X',game.getCiclos());
						//zombielist.aniadir(zom);
						game.nuevoZombie(zom);
						/*
						template.setBoard('Z', x, y,zom.getResistencia() );
						*/

						numZombies++;
					}
				}
				else if(level == Level.INSANE) {
					if(probabilidad != 0 && probabilidad != 1 && probabilidad != 2) { //7 entre 10
						while(!existe) {
							if(printer.isEmpty(x, y,game.getObjectList())) {
								existe = true;
							}
							else {
								 x = rand.nextInt(4);
							}
						}
						
						int z = rand.nextInt(3);
						 
						 
						 if(z == 0) {
						zom = new Zombie(x,y,5,1,2,'Z',game.getCiclos());
						 }
						 else if(z == 1) zom = new ZombieLento(x,y,8,1,4,'W',game.getCiclos());
						 else zom = new ZombieDeportista(x,y,2,1,1,'X',game.getCiclos());
						//zombielist.aniadir(zom);
						game.nuevoZombie(zom);
						/*
						template.setBoard('Z', x, y,zom.getResistencia() );
						*/

						numZombies++;
						
					}
				}
				}
				return numZombies;
			}
		
		//public static String listOfAvilablePlants() { ... }
		
		public static String listOfAvilableZombies() { //almacena en mensaje los textos de cada subclase
			String mensaje = "";
			mensaje = "The available plant are:" + '\n';
			for(int n = 0; n < availableZombies.length; n++) {
				mensaje += availableZombies[n].getInfo() + '\n';
			}
			return mensaje;

		}
}
