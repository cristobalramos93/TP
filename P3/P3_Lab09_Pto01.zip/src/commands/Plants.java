package commands;

import tp.p3.BoardPrinter;
import tp.p3.Game;
import tp.p3.Petacereza;
import tp.p3.Sunflower;

public abstract class Plants extends GameObject {
	
	private int coste;
	private int danio;
	//private int frecuencia;
	 Sunflower sun;
	 Petacereza cereza;
	//private int ciclo;
	//char letra;
	public Plants(int x, int y, int vida,int coste,int frecuencia,int danio,char letra,int ciclo) {
		super(x, y, vida,letra,ciclo,frecuencia);
		this.coste = coste;
		this.danio = danio;
		//this.frecuencia = frecuencia;
		//this.ciclo = ciclo;
		//this.letra = letra;
	}
	




/*
	public char getLetra() {
		return letra;
	}
*/


	public int getDanio() {
		return danio;
	}





	public int getCoste() {
		return coste;
	}





	public void setCoste(int coste) {
		this.coste = coste;
	}





	public void setDanio(int danio) {
		this.danio = danio;
	}





	public void setLetra(char letra) {
		this.letra = letra;
	}

/*

	public int getFrecuencia() {
		return frecuencia;
	}
*/

	public int getCicloSun() {
		return sun.getCiclo();
	}
	public int getCicloCereza() {
		return cereza.getCiclo();
	}


/*
	public void setFrecuencia(int frecuencia) {
		this.frecuencia = frecuencia;
	}
*/



	public abstract void ataca(GameObjectList objectList,BoardPrinter printer,Game game);

	public Plants(String nombre,String info) {
		// TODO Auto-generated constructor stub
		super(nombre,info);
	}






}
