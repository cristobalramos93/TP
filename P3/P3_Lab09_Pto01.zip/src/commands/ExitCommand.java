package commands;

import tp.p3.Game;

public class ExitCommand extends NoParamsCommand{

	public ExitCommand() {
		super("exit", "terminate the program.");
	}

	
	

	public boolean execute(Game game){
		game.setFin(true);
		System.out.println("Has abandonado");
		this.setNoPrintGameState(false);
		return false;

	}




	





}
