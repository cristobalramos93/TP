package commands;

import exceptions.CommandExecuteException;
import exceptions.CommandParserException;
import tp.p3.Game;

public abstract class NoParamsCommand extends Command{
	

	public NoParamsCommand(String commandInfo, String helpInfo) {
		super(commandInfo, helpInfo);
	}

	public Command parse(String[] commandWords,GameObjectList objectList,Game game) throws CommandParserException {
		
			if(commandWords[0].equalsIgnoreCase(commandName)) {
				comandoLargo(commandWords);
				return this;
			}
			else return null;
		
		
	}
	
	
	public abstract boolean execute(Game game) throws CommandExecuteException;
	
	
	public static void comandoLargo(String[] palabra)throws CommandParserException{
		if(palabra.length > 1)
            throw new CommandParserException(palabra[0] +" Command has no arguments ");
              
	}

}

