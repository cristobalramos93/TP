package commands;
import exceptions.CommandExecuteException;
import exceptions.CommandParserException;
import tp.p3.Game;
	public abstract class Command {
		private String helpText;
		private String commandText;
		protected final String commandName;
		public boolean tab;
		
		public boolean isNoPrintGameState() {
			return tab;
		}


		
		public void setNoPrintGameState(boolean tab) {
			this.tab = tab;
		}



		public Command(String commandInfo, String helpInfo) {
			commandText = commandInfo;
			helpText = helpInfo;
			String[] commandInfoWords = commandText.split("\\s+"); 
			commandName = commandInfoWords[0];
		}

			
			
			public String helpText() {
				return " " + commandText + ": " + helpText;
			}
			
			public abstract boolean execute(Game game) throws CommandExecuteException; 
			public abstract Command parse(String[] commandWords,GameObjectList objectList,Game game) throws CommandParserException;
			
			
			
	} // Command

