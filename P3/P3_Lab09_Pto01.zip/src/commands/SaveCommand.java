package commands;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import exceptions.CommandExecuteException;

import exceptions.CommandParserException;
import tp.p3.Game;
import tp.p3.GamePrinter;

public class SaveCommand extends Command {
	String nombreArchivo;


	public SaveCommand() {
		super("save", "save the game.");

	}


	public SaveCommand(String commandInfo, String helpInfo) {
		super("Save", "save the game");
	}



	@Override
	public Command parse(String[] commandWords, GameObjectList objectList, Game game) throws CommandParserException {
		if (commandWords[0].equalsIgnoreCase("save")){


			if(commandWords.length == 2) {
				nombreArchivo = commandWords[1];
				return this;
			}


			else {
				argumentos(commandWords, 2);
				return null;

			}
		}
		else return null;
	}




	@Override
	public boolean execute(Game game) throws CommandExecuteException {
		GamePrinter printer = null;

		FileWriter fichero = null;

		try {
			if(printer.isValidFilename(nombreArchivo)) {
				fichero = new FileWriter(nombreArchivo);
				PrintWriter pw = new PrintWriter(fichero);

				pw.println("Plants Vs Zombies v3.0");
				pw.println();
				game.store(nombreArchivo, fichero, pw);
			}
			else System.out.println("Invalid filename: the filename contains invalid characters");

		}
		catch(IOException e){
			e.printStackTrace();
		}

		finally {
			try {
				// Nuevamente aprovechamos el finally para 
				// asegurarnos que se cierra el fichero.
				if (null != fichero)
					fichero.close();
			} catch (Exception e2) {
				e2.printStackTrace();

			}



		}

		return false;
	}


	public static void argumentos(String[] commandWords,int num)throws CommandParserException{
		if(commandWords.length != num)
			throw new CommandParserException("Incorrect number of arguments for save command: [S]ave : <file>");

	}
}
