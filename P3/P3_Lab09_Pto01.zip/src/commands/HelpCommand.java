package commands;

import tp.p3.Game;

public class HelpCommand extends NoParamsCommand{
	
	public HelpCommand() {
		super("help", "print this help message.");
	}


	
	public boolean execute(Game game){//llama a commandHelp que llama a todos los mensajes de la subclase
		String mensaje;
		mensaje = CommandParser.commandHelp();
		System.out.println(mensaje);
		this.setNoPrintGameState(false);
		return false;
		
	}

}
