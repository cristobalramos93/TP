package commands;

import tp.p3.Game;

public class ResetCommand extends NoParamsCommand{

	public ResetCommand() {
		super("r", "start a new game.");
	}



	public boolean execute(Game game){
		 game.reset();
		this.setNoPrintGameState(true);
		return true;

	}
}
