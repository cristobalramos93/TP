package commands;


import exceptions.CommandParserException;
import tp.p3.BoardPrinter;

import tp.p3.DebugPrinter;
import tp.p3.Game;
import tp.p3.ReleasePrinter;

public class PrintModeCommand extends NoParamsCommand{

	BoardPrinter printer;

	public PrintModeCommand() {
		super("PrintMode", "Change print mode [Release|Debug]");
		// TODO Auto-generated constructor stub
	}

	public PrintModeCommand( BoardPrinter printer) {
		super("PrintMode", "Change print mode [Release|Debug]");
		this.printer = printer;
	}

	public Command parse(String[] commandWords,GameObjectList objectList,Game game) throws CommandParserException{
		if (commandWords[0].equalsIgnoreCase("PrintMode")){

			nombrePrintIncorrecto(commandWords);
			argumentoPrintIncorrectos(commandWords);
				if(commandWords[1].equalsIgnoreCase("Release")) {
					System.out.println("You have chosen Release Mode");
					return new PrintModeCommand(new ReleasePrinter(4, 8,objectList, game));
				}
				else {
					return new PrintModeCommand(new DebugPrinter(0, objectList.ultimaPos(),objectList,game));
				}
			}
		return null;
			
		}

		

	

	public boolean execute(Game game){
		game.cambioDeTablero(printer);
		this.setNoPrintGameState(true);
		return true;
		//public Game(int ciclos,Random seed,Level level,SuncoinManager suncoin,GamePrinterTemplate template,GameObjectList objectList,BoardPrinter printer) {

	}



	public static void nombrePrintIncorrecto(String[] palabra)throws CommandParserException{
		if(palabra.length == 2 && !palabra[1].equalsIgnoreCase("Release") && !palabra[1].equalsIgnoreCase("Debug")){
			throw new CommandParserException("Unknown print mode: " + palabra[1]);

		}
	}


	public static void argumentoPrintIncorrectos(String[] palabra)throws CommandParserException{
		if(palabra.length != 2 ){
			throw new CommandParserException("Incorrect number of arguments for printmode command: [P]rintMode release|debug ");

		}

	}
}
