package commands;

import exceptions.CommandExecuteException;
import exceptions.CommandParserException;
import tp.p3.Game;

public class AddCommand extends NoParamsCommand{
	private int x;
	private int y;
	private String valor;
	
	public AddCommand() {
		super("a", " add flower");
	}
	
	
	AddCommand(int x, int y, String valor){
		super("add", " add flower");
		this.x = x;
		this.y = y;
		this.valor = valor;
	}
	
	
	
	public Command parse(String[] commandWords,GameObjectList objectList,Game game) throws CommandParserException{
		if (commandWords[0].equalsIgnoreCase("a")){
			
			if(commandWords.length == 4 && commandWords[1].equalsIgnoreCase("s") || commandWords[1].equalsIgnoreCase("p") || commandWords[1].equalsIgnoreCase("c")|| commandWords[1].equalsIgnoreCase("n") ){
				return new AddCommand(Integer.parseInt(commandWords[2]),Integer.parseInt(commandWords[3]),commandWords[1]);
			}
			
			else {
				argumentos(commandWords,4);
				comandoNulo(commandWords);
				return null;
			}
		}
		
		else {
			//System.out.println("Comando no valido. Escribe help para ver la ayuda");
			return null;
		}
	
	}
	
	

	public boolean execute(Game game) throws CommandExecuteException {//llama a commandHelp que llama a todos los mensajes de la subclase
		boolean mostrar = false;
		Plants plants = PlantFactory.getPlant(this.valor, x,  y,game);
		if(plants!= null) {
		mostrar = game.addPlantToGame(x, y, plants);
		//if(mostrar == true)	this.setNoPrintGameState(true);
		//else this.setNoPrintGameState(false);

		}
		//update();
	//	game.userCommand(x, y, valor);
		return mostrar;
		
	}
	public static void comandoNulo(String[] palabra)throws CommandParserException{
            throw new CommandParserException("Unknown plant name: "+ palabra[1]);
              
	}
	
	public static void argumentos(String[] commandWords,int num)throws CommandParserException{
		if(commandWords.length != num)
        throw new CommandParserException("Incorrect number of arguments for add command: [A]dd : <plant> <x> <y>");
          
}

	
}
