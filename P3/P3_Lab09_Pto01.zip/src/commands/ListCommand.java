package commands;

import tp.p3.Game;

public class ListCommand extends NoParamsCommand{
	
	public ListCommand() {
		super("list", " print the list of available plants");
	}
	

	

	public boolean execute(Game game){//llama a commandHelp que llama a todos los mensajes de la subclase
		String m;
		m = PlantFactory.listOfAvilablePlants();
		System.out.println(m);
		//System.out.println("holaaaa");
		return false;

	}
}

