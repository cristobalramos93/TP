package commands;

import tp.p3.Game;

public class ListZombies extends NoParamsCommand{
	
	public ListZombies() {
		super("zombielist", " print the list of available zombies");
	}
	

	

	public boolean execute(Game game){//llama a commandHelp que llama a todos los mensajes de la subclase
		String m;
		m = ZombiesFactory.listOfAvilableZombies();
		System.out.println(m);
		this.setNoPrintGameState(false);
		return false;

	}
}
