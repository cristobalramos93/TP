package commands;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;




import exceptions.CommandExecuteException;
import exceptions.CommandParserException;
import tp.p3.Game;
import tp.p3.GamePrinter;

public class LoadCommand extends Command {
	String nombreArchLoad;


	public LoadCommand() {
		super("load", "load the game.");

	}


	public LoadCommand(String commandInfo, String helpInfo) {
		super("Load", "load the game");
	}



	@Override
	public Command parse(String[] commandWords, GameObjectList objectList, Game game) throws CommandParserException {
		if (commandWords[0].equalsIgnoreCase("load") ) {

			if(commandWords.length == 2) {
				nombreArchLoad = commandWords[1];
				return this;
			}
			
			else {
				argumentos(commandWords, 2);
				return null;	
			}
		}
		else return null;
	}



	public static void argumentos(String[] commandWords,int num)throws CommandParserException{
		if(commandWords.length != num)
			throw new CommandParserException("Incorrect number of arguments for load command: [L]oad : <file>");

	}





	@Override
	public boolean execute(Game game) throws CommandExecuteException {
		GamePrinter printer = null;
		if(printer.isValidFilename(nombreArchLoad) && printer.isReadable(nombreArchLoad)) {
			String tipee;
			boolean estaLaLinea = false;

			int cont = 0;
			//llamar a parse() de gametype
			File archivo = null;
			FileReader fr = null;
			BufferedReader br = null;

			try {
				// Apertura del fichero y creacion de BufferedReader para poder
				// hacer una lectura comoda (disponer del metodo readLine()).
				archivo = new File (nombreArchLoad);
				fr = new FileReader (archivo);
				br = new BufferedReader(fr);
				// Lectura del fichero
				String linea = null;
				linea=br.readLine(); //lee una linea del tablero
				if(linea.equalsIgnoreCase("Plants Vs Zombies v3.0")) {
					estaLaLinea = true;
				}

				lineaperdida(estaLaLinea);
				linea=br.readLine(); //lee una linea del tablero
				if(linea.length() == 0) {
					game.load(nombreArchLoad,br,fr);
				}
				else estaLaLinea = false;

				lineaperdida(estaLaLinea);


			}
			catch(CommandExecuteException ex) {
				String respuesta;
				respuesta = ex.getMessage();
				System.out.println(respuesta);
				return false;
			}
		
			catch(Exception e){
				// e.printStackTrace();
				return false;

			}finally{
				// En el finally cerramos el fichero, para asegurarnos
				// que se cierra tanto si todo va bien como si salta 
				// una excepcion.
				try{                    
					if( null != fr ){   
						fr.close();  
					}                  
				}catch (Exception e2){ 
					return false;
					//e2.printStackTrace();
				}

			}

			return true;
		}
		else {
			System.out.println("File not found");
			return false;
		}



	}


	static void lineaperdida(boolean esta)throws CommandExecuteException{
		if((!esta)){
			throw new CommandExecuteException("Load failed: invalid file format");
		}
	}
}

