package commands;

import exceptions.CommandParserException;
import tp.p3.Game;

public class CommandParser {
	
	private static Command[] availableCommands = { new HelpCommand(), new ResetCommand(), new ExitCommand(), new AddCommand(), new ListCommand(),new UpdateCommand(),new ListZombies(),new PrintModeCommand(),new SaveCommand(),new LoadCommand()};
	
	public static Command parseCommand(String[] commandWords,GameObjectList objectList,Game game) throws CommandParserException{
		Command com = null;
		boolean encontrado = false;
		int n = 0;
		while(n < availableCommands.length && !encontrado){
				com=availableCommands[n].parse(commandWords,objectList,game);
				n++;
				if(com != null){
					encontrado = true;
				}	
		}
		comandoNulo(com,commandWords);
		return com;
	}
	
	
	
	public static String commandHelp() { //almacena en mensaje los textos de cada subclase
		String mensaje = "";
		mensaje = "The available commands are:";
		mensaje += '\n';
		for(int n = 0; n < availableCommands.length; n++) {
			
			mensaje += "	" + availableCommands[n].helpText();
			mensaje += '\n';
		}
		return mensaje;

	}
	
	
	public static void comandoNulo(Command com,String[] palabra)throws CommandParserException{
		if(com == null)
            throw new CommandParserException(palabra[0] + " is an unknown command. Use help to see the available commands" );
              
	}
	
	
	
}
