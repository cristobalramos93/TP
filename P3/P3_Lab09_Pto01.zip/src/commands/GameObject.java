package commands;

import tp.p3.Zombie;

public abstract class GameObject {
	private int x;
	private int y;
	private int vida;
	private int ciclo;
	private int frecuencia;
	public int getCiclo() {
		return ciclo;
	}
	public void setCiclo(int ciclo) {
		this.ciclo = ciclo;
	}

	//private int danio;
	char letra;
	
	//private int ciclo;
	Plants planta;
	Zombie zombie;
	public GameObject(int x, int y,int vida,char letra,int ciclo,int frecuencia) {
		this.x = x;
		this.y = y;
		this.vida = vida;
		//this.danio = danio;
		this.letra = letra;
		this.ciclo = ciclo;
		this.frecuencia = frecuencia;
	}
	public int getFrecuencia() {
		return frecuencia;
	}
	public void setFrecuencia(int frecuencia) {
		this.frecuencia = frecuencia;
	}
	public int getCicloSol() {
		return planta.getCicloSun();
	}
	
	public int getCicloCere() {
		return planta.getCicloCereza();
	}
	
	public int getDanio(){
		return planta.getDanio();
	}
	public int getDanioZ() {
		return zombie.getDanio();
	}
	/*
	public int getVelocidad() {
		return zombie.getVelocidad();
	}
	*/
	private String nombre;
	private String info;
	//private String listMessage;
	
	
	public GameObject(String nombre,String info) {
		//String[] infoWord = info.split("\\s+");
		this.nombre = nombre;
		this.info = info;
		// TODO Auto-generated constructor stub
	}
	
	
	public String getNombre() {
		return nombre;
	}
	public String getInfo() {
		return info;
	}
	public char getLetra() {
		return letra;
	}
	public void setLetra(char letra) {
		this.letra = letra;
	}
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}
	/*
	public GameObject(char nom) {
		this.nomm= nom;

	}
	*/
	/*
	public int getFrecuenciaPlanta() {
		return planta.getFrecuencia();

		
	}
	*/
	
	public int getX() {
		//System.out.println("hola");
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}

	
	
	//public abstract void update();
	
}
