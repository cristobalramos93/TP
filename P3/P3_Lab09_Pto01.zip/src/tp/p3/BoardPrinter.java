package tp.p3;

import commands.GameObjectList;

public abstract class BoardPrinter implements PintarTablero {

	String[][] board;
	String[][] board2;

	final String space = " ";
	int dimX;
	int dimY;

	
	public SuncoinManager getCoins() {
		return coins;
	}
	SuncoinManager coins;
	Game game;
	GameObjectList objectList;
	
	
	public BoardPrinter( int dimX, int dimY,GameObjectList objectList,Game game) {
		this.dimX = dimX;
		this.dimY = dimY;
		this.objectList = objectList;
		this.game =game;
		//encodeGame();
		//pintarTablero(objectList, game);
	}
	
	
	
	public String[][] getBoard() {
		return board;
	}
	
	//public abstract void setBoard(char c, int x, int y, int res);
	/*
	public void setBoardVacia(int x, int y) {
		board[x][y] =  space;
	}
	*/
	
	public boolean isEmpty(int x, int y,GameObjectList list){ //si el valor de la celda es Z devuelve true
		boolean vacio = true;
		  for(int i = 0; i < list.ultimaPos();i++) {
			  if(list.getObjeto(i).getX() == x && list.getObjeto(i).getY() == y) {
				  vacio = false;
			  }
		  }
		  return vacio;
		}		  
		  
	public void boardToString(Game game, GameObjectList objectList) {
		this.printGame(game, objectList);
	}
	public abstract void encodeGame(Game game,GameObjectList objectList);
	//public abstract String toString(Game game,GameObjectList list);
	public abstract void mostrarMensaje(Game game);
	public abstract void pintarTablero(GameObjectList objectList,Game game);
//	public abstract boolean isEmpty(int x, int y,GameObjectList list);
}