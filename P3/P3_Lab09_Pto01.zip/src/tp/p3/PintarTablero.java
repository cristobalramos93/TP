package tp.p3;

import commands.GameObjectList;

public interface PintarTablero {

	public String printGame(Game game,GameObjectList objectList);	
}
