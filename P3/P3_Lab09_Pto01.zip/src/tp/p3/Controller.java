package tp.p3;



import java.util.Scanner;

import commands.Command;
import commands.CommandParser;
import exceptions.CommandExecuteException;
import exceptions.CommandParserException;

public class Controller {

	private Game game;
	private Scanner in;
	PlantsVsZombies pz;
	BoardPrinter printer;
	Level level;
	public Controller(Game game, Scanner in) {
		this.game = game;
		this.in = in;
	}

	public void run()  {
		System.out.println("Welcome to PlantsVsZombies v3.0");
		System.out.println(game.getPrinter().printGame(game,game.getObjectList()));

	
		while(!game.isFin()){
		try {
			String[] words;
			System.out.println("Command > ");
			words = in.nextLine().split(" ");
			Command comando = CommandParser.parseCommand(words,game.getObjectList(),game);

					 if(comando.execute(game) && !game.isFin() ) {
						System.out.println(game.getPrinter().printGame(game,game.getObjectList()));

					}
		}
		catch( CommandExecuteException ex) {
			System.out.format(ex.getMessage() + "%n%n");
		}
		catch( CommandParserException ex) {
			System.out.format(ex.getMessage() + "%n%n");

		}
		
		}
	}

}

