package tp.p3;

import commands.GameObjectList;
import commands.Plants;

public class Petacereza extends Plants {

	//private int ciclo;
	
	
	public Petacereza() {
		super("C","Peta[c]ereza: Cost: 50 suncoins Harm: 10 ");
	}
	public Petacereza(int x, int y, int coste, int resistencia, int danio, int frecuencia, int ciclo,char letra ) {
		super(x,y,resistencia,coste,frecuencia,danio,letra,ciclo);
		//this.x = x;
		//this.y = y;
		//this.coste = coste;
		//this.resistencia = resistencia;
		//this.danio = danio;
		//this.frecuencia = frecuencia;
		//this.ciclo = ciclo;
	}
	
	/*
	public int getCiclo() {
		return ciclo;
	}
	public void setCiclo(int ciclo) {
		this.ciclo = ciclo;
	}
	*/
	GameObjectList objectList;
	//GamePrinterTemplate template;
	Game game;
	public void ataca(GameObjectList objectList,BoardPrinter printer,Game game) {
		//Petacereza cere;
		//for(int i = 0; i < objectList.ultimaPos();i++) {
			//if(objectList.getObjeto(i).getLetra() == 'C') {
				//cere = (Petacereza) objectList.getObjeto(i);

				int resul;
				resul = ( game.getCiclos() - this.getCiclo()) % this.getFrecuencia();
				if( resul == 0) { //esta mal seguro ese getCiclo
					if( (game.getCiclos() - this.getCiclo() != 0) ) {
					
					for(int j = 0; j < objectList.ultimaPos();j++) {

					if(this.getX() != 3 && this.getX() == objectList.getObjeto(j).getX() +1 && this.getY() == objectList.getObjeto(j).getY()) {//si esta debajo
						objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - this.getDanio());//le quitas 10 de vida
						//printer.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero

					}
					 if(this.getX() != 0 && this.getX() == objectList.getObjeto(j).getX() - 1 && this.getY() == objectList.getObjeto(j).getY()) { // si esta arriba
						objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - this.getDanio());//le quitas 10 de vida
					//	printer.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero

					}
					 if(this.getY() != 7 && this.getY() == objectList.getObjeto(j).getY() + 1 && this.getX() == objectList.getObjeto(j).getX()) { // si esta a la derecha
						objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - this.getDanio());//le quitas 10 de vida
					//	printer.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero

					}
					 if(this.getY() != 0 && this.getY() == objectList.getObjeto(j).getY() - 1 &&  this.getX() == objectList.getObjeto(j).getX()) { // si esta a la izquierda
						objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - this.getDanio());//le quitas 10 de vida
					//	printer.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero

					}
					 if(this.getX() != 0 && this.getY() != 7 && this.getX() == objectList.getObjeto(j).getX() - 1 &&  this.getY() == objectList.getObjeto(j).getY() + 1) { // si esta a la arriba derecha
						objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - this.getDanio());//le quitas 10 de vida
					//	printer.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero
					}
					 if(this.getX() != 0 && this.getY() != 0 && this.getX() == objectList.getObjeto(j).getX() - 1 &&  this.getY() == objectList.getObjeto(j).getY()-1) { // si esta a la arriba izquierda
						objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - this.getDanio());//le quitas 10 de vida
					//	printer.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero
					}
					 if(this.getX() != 3 && this.getY() != 7 && this.getX() == objectList.getObjeto(j).getX() + 1 &&  this.getY() == objectList.getObjeto(j).getY()+1) { // si esta a la abajo derecha
						objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - this.getDanio());//le quitas 10 de vida
					//	printer.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero
					}
					 if(this.getX() != 3 && this.getY() != 0 && this.getX() == objectList.getObjeto(j).getX() + 1 &&  this.getY() == objectList.getObjeto(j).getY()-1) { // si esta a la abajo izquierda
						objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - this.getDanio());//le quitas 10 de vida
						//printer.setBoard(objectList.getObjeto(j).getLetra(), objectList.getObjeto(j).getX(), objectList.getObjeto(j).getY(), objectList.getObjeto(j).getVida()); //modifico tablero
					}
					}
					this.setVida(0);//la planta muere despues de explotar
					//printer.setBoardVacia(this.getX(), this.getY());//lo borro del tablero

					}
				}
			}
		//}
	//}
}
