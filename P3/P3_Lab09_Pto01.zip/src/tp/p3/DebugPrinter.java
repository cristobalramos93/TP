package tp.p3;

import commands.GameObject;
import commands.GameObjectList;

public class DebugPrinter extends BoardPrinter {

	//GameObjectList objectList;
	//String[][] board;
	public DebugPrinter(int dimX, int dimY,GameObjectList objectList,Game game) {
		super(dimX, dimY,objectList,game);
		//this.objectList = objectList;
		// TODO Auto-generated constructor stub
	}
	
	
	//String[][] board2;

	
	
	@Override
	public void encodeGame(Game game,GameObjectList objectList) {
		
		board = new String[1][32];
			for(int j = 0; j < 32; j++) {
				 board[0][j] =  space;
				}
			
			pintarTablero(objectList, game);
	}

	
	
	public void pintarTablero(GameObjectList objectList,Game game) {
		for(int i = 0; i < objectList.ultimaPos();i++) {
			setBoard2(game.getCiclos(),objectList.getObjeto(i),objectList,i);
		}
	}
	
	
	
	public void setBoard2(int turno,GameObject object,GameObjectList list,int i) {
		int num = object.getCiclo() % object.getFrecuencia();
		int num2 = turno - num;
		int num3 = num2 % object.getFrecuencia();
		int num4 = object.getFrecuencia() - num3;
		if(num4 == object.getFrecuencia()) num4 = 0;
		

		this.board[0][i] = object.getLetra() + " [l:" + object.getVida() + ",x:"+ object.getX() + ",y:"+ object.getY() + ",t:"+  num4  + "]" ;
	}

	//public String toString(Game game,GameObjectList objectList)
	

	
	public void mostrarMensaje(Game game) {
		int quedan;
		System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
		System.out.println("Level: " + game.getLevel());
		System.out.println("Number of cycles: " + (game.getCiclos()-1));
		System.out.println("Sun coins: " + game.suncoin.getSuncoins());
		quedan = game.zombiesQuedan();
		System.out.println("Remaining zombies: " + quedan);  //zombies que quedan por salir
	}


	@Override
	public String printGame(Game game,GameObjectList objectList) {
		mostrarMensaje(game);
		encodeGame(game,objectList);
		//pintarTablero(objectList, game);
		int cellSize = 25;
		int marginSize = 2;
		String vDelimiter = "|";
		String hDelimiter = "-";
		
		String rowDelimiter = GamePrinter.repeat(hDelimiter, (objectList.ultimaPos() * (cellSize + 1)) - 1);
		String margin = GamePrinter.repeat(space, marginSize);
		String lineDelimiter = String.format("%n%s%s%n", margin + space, rowDelimiter);
		
		StringBuilder str = new StringBuilder();
		
		str.append(lineDelimiter);
		
		for(int i=0; i<1; i++) {
				str.append(margin).append(vDelimiter);
				for (int j=0; j<objectList.ultimaPos(); j++) {
					str.append( GamePrinter.centre(board[i][j], cellSize)).append(vDelimiter);
				}
				str.append(lineDelimiter);
		}
				
		return str.toString();
		
	}

		//public void setBoard(char c, int x, int y, int res) {
		// TODO Auto-generated method stub
		
	}

/*
	@Override
	public void setBoard(char c, int x, int y, int res) {
		// TODO Auto-generated method stub
		
	}
	*/




