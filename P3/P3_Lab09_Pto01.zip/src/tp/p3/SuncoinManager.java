package tp.p3;

import commands.GameObject;
import commands.GameObjectList;

public class SuncoinManager {
	
	GameObject obj;
	GameObjectList list;
	private int suncoins;//lleva el control de los suncoins

	public SuncoinManager(int suncoins) {
		this.suncoins = suncoins;
	}

	public int getSuncoins() {
		return suncoins;
	}

	public void setSuncoins(int suncoins) {
		this.suncoins = suncoins;
	}


	
}
