package tp.p3;


import commands.GameObjectList;
import commands.Plants;

public class Peashooter extends Plants {
	

	public Peashooter(){
		super("P","[P]eashooter: Cost: 50 suncoins Harm: 1 ");
	}
	
	public Peashooter(int x, int y, int coste, int resistencia, int danio, int frecuencia,char letra,int ciclo) {
		super(x,y,resistencia,coste,frecuencia,danio,letra,ciclo);

	}


	Game game;
	GameObjectList objectList;
	//GamePrinterTemplate template;
	
	
	public void ataca(GameObjectList objectList,BoardPrinter printer,Game game) { // de la lista de guisantes, busca si hay zombies en su fila de la lista de zombies
			boolean atacado = false;
			for(int j = 0; j < objectList.ultimaPos(); j++) {
				if((objectList.getObjeto(j).getLetra() == 'Z'|| objectList.getObjeto(j).getLetra() == 'W' || objectList.getObjeto(j).getLetra() == 'X' ) && this.getX() == objectList.getObjeto(j).getX() && objectList.getObjeto(j).getVida() > 0 && !atacado) { //si esta en su fila y esta vivo y si es un zombie
					objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() -  this.getDanio()); // ataca
					atacado = true; //para que solo ataque una vez
			}
		}
	}

}
