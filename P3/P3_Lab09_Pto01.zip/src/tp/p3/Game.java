package tp.p3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;


import commands.GameObject;
import commands.GameObjectList;
import commands.Plants;
import commands.PrintModeCommand;
import commands.Zombies;
import commands.ZombiesFactory;
import exceptions.CommandExecuteException;
import exceptions.FileContentsException;

public class Game {

	GameObject obj;
	private Plants planta;
	public int ciclos; //contador de ciclos, empieza en 1
	public Random rand;
	Sunflower sun;
	Peashooter pea;
	Level level;
	SuncoinManager suncoin;
	public int numZombies = 0;
	public int quedan = 100;
	private boolean fin = false;
	PlantsVsZombies pz;
	private GameObjectList objectList;
	private BoardPrinter printer;
	DebugPrinter debug;

	public Game(int ciclos,Random seed,Level level,SuncoinManager suncoin/*,GamePrinterTemplate template*/,GameObjectList objectList,BoardPrinter printer) {
		this.ciclos = ciclos;
		this.rand = seed;
		this.level = level;
		this.suncoin = suncoin;
		this.objectList = objectList;
		this.printer = printer;
	}


	public void update() {

		sumaSoles();
		atacaPlantas();
		atacaZombie();
		avanzanZombies();
		muerte();
		numZombies = ZombiesFactory.getZombie(level,rand,printer,numZombies,quedan, this); // aparicion de zombie y devuelvo el contador de zombies
		ciclos++;
		hasGanado();
		hasPerdido();

	}


	public void atacaPlantas() { //cada una ataca en su clase, de esta manera lo hacen por orden de creacion
		for(int i = 0; i < objectList.ultimaPos(); i++) {
			if(objectList.getObjeto(i).getLetra() == 'P' || objectList.getObjeto(i).getLetra() == 'C') {
				planta = (Plants) objectList.getObjeto(i);
				planta.ataca(objectList,printer,this);
			}
		}
	}

	public BoardPrinter getPrinter() {
		return printer;
	}


	public void setPrinter(BoardPrinter printer) {
		this.printer = printer;
	}


	public int getCiclos() {
		return ciclos;
	}

	public void sumaSoles() { // para cada girasol suma soles si llevan dos turnos sin dar

		for(int i = 0; i < objectList.ultimaPos(); i++) {
			if(objectList.getObjeto(i).getLetra() == 'S') {
				sun = (Sunflower) objectList.getObjeto(i);
				int res;
				res = (ciclos-sun.getCiclo()) %sun.getFrecuencia();
				if(res == 0) { 
					if(ciclos-sun.getCiclo() != 0) {//si desde que le an puesto, lleva un turno sin dar
						suncoin.setSuncoins(suncoin.getSuncoins() + 10); //si le toca hace soles totales + 10
					}
				}
			}
		}

	}


	Zombies zombie;
	public void avanzanZombies() {
		for(int i = 0; i < objectList.ultimaPos(); i++) {
			if(objectList.getObjeto(i).getLetra() == 'Z' || objectList.getObjeto(i).getLetra() == 'W' || objectList.getObjeto(i).getLetra() == 'X') {
				zombie = (Zombies) objectList.getObjeto(i);
				zombie.avanza(this,printer,objectList);
			}
		}
	}

	public void atacaZombie() { // de la lista de guisantes, busca si hay zombies en su fila de la lista de zombies

		Zombies zom;
		for(int i = 0; i < objectList.ultimaPos(); i++) { //ataca a guisante
			if(objectList.getObjeto(i).getLetra() == 'Z' || objectList.getObjeto(i).getLetra() == 'X' || objectList.getObjeto(i).getLetra() == 'W' ) {
				for(int j = 0; j < objectList.ultimaPos(); j++) {
					if(objectList.getObjeto(j).getLetra() == 'P' || objectList.getObjeto(j).getLetra() == 'S' || objectList.getObjeto(j).getLetra() == 'C' || objectList.getObjeto(j).getLetra() == 'N') {
						if(objectList.getObjeto(i).getVida() > 0) { //si esta vivo
							if(objectList.getObjeto(i).getX() == objectList.getObjeto(j).getX() && objectList.getObjeto(i).getY() == objectList.getObjeto(j).getY() + 1) { //si esta a su izquierda


								if(objectList.getObjeto(i).getLetra() == 'Z') {
									zom = (Zombie) objectList.getObjeto(i);
								}
								else if(objectList.getObjeto(i).getLetra() == 'X') {
									zom = (ZombieDeportista) objectList.getObjeto(i);
								}
								else zom = (ZombieLento) objectList.getObjeto(i);

								objectList.getObjeto(j).setVida(objectList.getObjeto(j).getVida() - zom.getDanio()); //le quita uno de danio en la lista
							}
						}
					}
				}
			}
		}
	}

	public void muerte() {

		for(int i = 0; i < objectList.ultimaPos(); i++) {
			if(objectList.getObjeto(i).getVida() <= 0) {
				objectList.borrar(i); //borro de la lista
				i--;
			}
		}

	}

	public void hasPerdido() {

		if(fin == false) {
			for(int i = 0; i < objectList.ultimaPos(); i++) {
				if((objectList.getObjeto(i).getLetra() == 'Z' || objectList.getObjeto(i).getLetra() == 'W' || objectList.getObjeto(i).getLetra() == 'X' ) && objectList.getObjeto(i).getY() == 0) {
					fin = true;
				}
			}
			if(fin == true) {
				System.out.println(printer.printGame(this,objectList));
				System.out.println("Has perdido!");

			}
		}
	}

	public void hasGanado() {
		int cont = 0;
		if (fin != true) {
			for(int i = 0; i < objectList.ultimaPos(); i++) {
				if(objectList.getObjeto(i).getLetra() == 'Z' || objectList.getObjeto(i).getLetra() == 'W' || objectList.getObjeto(i).getLetra() == 'X' ) cont ++;
			}
			if(Level.INSANE == level && cont == 0) {
				if(numZombies == 10) {
					fin = true;
				}
			}
			if(Level.EASY == level && cont == 0) {
				if(numZombies == 3) {
					fin = true;
				}
			}
			if(Level.HARD == level) {
				if(numZombies == 5 && cont == 0) {
					fin = true;
				}
			}
			if(fin == true) {
				System.out.println(printer.printGame(this,objectList));

				System.out.println("Has ganado!");
			}
		}
	}

	public Level getLevel() {
		return level;
	}

	public int zombiesQuedan(){
		if(Level.INSANE == level) {
			quedan = 10-numZombies;
		}
		if(Level.EASY == level) {
			quedan = 3-numZombies;

		}
		if(Level.HARD == level) {
			quedan = 5-numZombies;

		}
		return quedan;

	}



	public boolean isFin() {
		return fin;
	}





	public void setFin(boolean fin) {
		this.fin = fin;
	}




	public Random getRand() {
		return rand;
	}




	public void cambioDeTablero(BoardPrinter printer) {
		this.printer = printer;

	}

	public boolean addPlantToGame(int x, int y, Plants planta) throws CommandExecuteException{
		boolean puesto = false;
		posicionesNoValidas(x, y,planta);
		posicionOcupada(x, y, planta);
		noQuedanSoles(planta);
		puesto = true;
		objectList.aniadir(planta);
		update();
		return puesto;
	}



	public void posicionesNoValidas(int x,int y,Plants planta) throws CommandExecuteException{
		if(x > 3 || y > 7 || x < 0 || y < 0){

			throw new CommandExecuteException("Failed to add "+ planta.getLetra() + " : (" + x +", "+ y+") is an invalid position ");
		}
		else if(y == 7) throw new CommandExecuteException("No se puede colocar una planta en la ultima columna");

	}
	public void posicionOcupada(int x,int y,Plants planta) throws CommandExecuteException{
		if(!printer.isEmpty(x,y,objectList)){
			throw new CommandExecuteException("Failed to add "+ planta.getLetra() + " : (" + x +", "+ y+") is already ocupied ");
		}

	}


	public void noQuedanSoles(Plants planta) throws CommandExecuteException{
		if(suncoin.getSuncoins() - planta.getCoste() >= 0) { // comprueba que tenga soles suficientes
			suncoin.setSuncoins(suncoin.getSuncoins() - planta.getCoste());
		}
		else throw new CommandExecuteException("Failed to add "+ planta.getLetra() + ": not enough suncoins to buy it ");


	}






	public GameObjectList getObjectList() {
		return objectList;
	}


	public void setObjectList(GameObjectList objectList) {
		this.objectList = objectList;
	}


	public void nuevoZombie(Zombies zom) {
		objectList.aniadir(zom);
	}

	public int proximaAccion(int ciclo,int turno,int frecuencia) {
		int num = ciclo % frecuencia;
		int num2 = turno - num;
		int num3 = num2 % frecuencia;
		int num4 = frecuencia - num3;
		if(num4 == frecuencia) num4 = 0;
		return num4;
	}



	public void store(String nombreArch,FileWriter fichero,PrintWriter pw) {

		pw.println( "cycle: " + (this.ciclos -1));
		pw.println( "sunCoins: " + this.suncoin.getSuncoins());
		pw.println( "level: " + this.level);
		pw.println( "remZombies: " + this.quedan);
		pw.print( "plantList: ");
		for(int i = 0; i < objectList.ultimaPos(); i++) {
			if(objectList.getObjeto(i).getLetra() == 'P' || objectList.getObjeto(i).getLetra() == 'C'|| objectList.getObjeto(i).getLetra() == 'N'|| objectList.getObjeto(i).getLetra() == 'S') {
				int proximaAccion = proximaAccion(objectList.getObjeto(i).getCiclo(), this.ciclos, objectList.getObjeto(i).getFrecuencia());
				pw.print(objectList.getObjeto(i).getLetra() + ":" + objectList.getObjeto(i).getVida() + ":" + objectList.getObjeto(i).getX() + ":" + objectList.getObjeto(i).getY() + ":" + proximaAccion + ", " );
			}
		}
		pw.println();
		pw.print( "zombieList: ");
		for(int i = 0; i < objectList.ultimaPos(); i++) {
			if(objectList.getObjeto(i).getLetra() == 'Z' || objectList.getObjeto(i).getLetra() == 'X'|| objectList.getObjeto(i).getLetra() == 'W') {
				int proximaAccion = proximaAccion(objectList.getObjeto(i).getCiclo(), this.ciclos, objectList.getObjeto(i).getFrecuencia());
				pw.print(objectList.getObjeto(i).getLetra() + ":" + objectList.getObjeto(i).getVida() + ":" + objectList.getObjeto(i).getX() + ":" + objectList.getObjeto(i).getY() + ":" + proximaAccion + ", " );
			}
		}
		System.out.println("Game successfully saved in file " + nombreArch + ".dat. Use the load command to reload it");



	}


	public void reset() {
		this.ciclos = 1;
		this.suncoin = new SuncoinManager(PlantsVsZombies.getSoles());
		this.numZombies = 0;
		this.objectList = new GameObjectList();
		quedan = zombiesQuedan();
	}

	public void load(String nombreArchLoad, BufferedReader br,FileReader fr) throws IOException {
		try {
			printer = new ReleasePrinter(4,8,objectList,this);
			Plants planta = null;
			Zombies zom = null;
			String linea = null;
			linea=br.readLine();
			String[] numerosComoArray = linea.split(" "); //parto el string por cada espacio
			this.ciclos = Integer.parseInt(numerosComoArray[1]) +1;

			linea=br.readLine();
			numerosComoArray = linea.split(" "); //parto el string por cada espacio
			this.suncoin = new SuncoinManager(Integer.parseInt(numerosComoArray[1]));

			linea=br.readLine();
			numerosComoArray = linea.split(" "); //parto el string por cada espacio
			this.level = level.parse(numerosComoArray[1]);
			malContenido(level);

			linea=br.readLine();
			numerosComoArray = linea.split(" "); //parto el string por cada espacio
			this.quedan = Integer.parseInt(numerosComoArray[1]);

			linea=br.readLine();
			numerosComoArray = linea.split(" "); //parto el string por cada espacio
			this.objectList = new GameObjectList();
			for(int i = 1; i < numerosComoArray.length ;i++) {
				if(numerosComoArray[i].charAt(0) == 'P') {
					planta = new Peashooter(Character.getNumericValue(numerosComoArray[i].charAt(4)), Character.getNumericValue(numerosComoArray[i].charAt(6)), 50, Character.getNumericValue(numerosComoArray[i].charAt(2)), 1, 1,'P', (this.ciclos - Character.getNumericValue(numerosComoArray[i].charAt(8))) );
					//public Peashooter(int x, int y, int coste, int resistencia, int danio, int frecuencia,char letra,int ciclo) {

				}
				if(numerosComoArray[i].charAt(0) == 'S') {
					planta = new Sunflower(Character.getNumericValue(numerosComoArray[i].charAt(4)), Character.getNumericValue(numerosComoArray[i].charAt(6)), 20, Character.getNumericValue(numerosComoArray[i].charAt(2)), 0, 3, (this.ciclos - (3 -Character.getNumericValue(numerosComoArray[i].charAt(8)))),'S' );
					//	public Sunflower(int x, int y, int coste, int resistencia, int danio, int frecuencia, int ciclo,char letra ) {

				}
				if(numerosComoArray[i].charAt(0) == 'N') {
					planta = new Nuez(Character.getNumericValue(numerosComoArray[i].charAt(4)), Character.getNumericValue(numerosComoArray[i].charAt(6)), 50, Character.getNumericValue(numerosComoArray[i].charAt(2)), 0, 1,'N',(this.ciclos - Character.getNumericValue(numerosComoArray[i].charAt(8))) );
					//	public Nuez(int x, int y, int coste, int resistencia, int danio, int frecuencia,char letra,int ciclo ) {

				}
				if(numerosComoArray[i].charAt(0) == 'C') {
					planta = new Petacereza(Character.getNumericValue(numerosComoArray[i].charAt(4)), Character.getNumericValue(numerosComoArray[i].charAt(6)), 50, Character.getNumericValue(numerosComoArray[i].charAt(2)), 10, 2,(this.ciclos - (2 - Character.getNumericValue(numerosComoArray[i].charAt(8)))),'C' );
					//	public Petacereza(int x, int y, int coste, int resistencia, int danio, int frecuencia, int ciclo,char letra ) {

				}

				objectList.aniadir(planta);
			}

			linea=br.readLine();
			numerosComoArray = linea.split(" "); //parto el string por cada espacio
			int cont = 0;
			for(int i = 1; i < numerosComoArray.length ;i++) {
				cont++;
				if(numerosComoArray[i].charAt(0) == 'Z') {
					zom = new Zombie(Character.getNumericValue(numerosComoArray[i].charAt(4)), Character.getNumericValue(numerosComoArray[i].charAt(6)),Character.getNumericValue(numerosComoArray[i].charAt(2)), 1, 2,'Z', (this.ciclos - (2 -Character.getNumericValue(numerosComoArray[i].charAt(8)))) );
					//public Zombies(int x, int y, int vida,int danio,int frecuencia,char letra,int ciclo) {

				}
				if(numerosComoArray[i].charAt(0) == 'W') {
					zom = new ZombieLento(Character.getNumericValue(numerosComoArray[i].charAt(4)), Character.getNumericValue(numerosComoArray[i].charAt(6)),Character.getNumericValue(numerosComoArray[i].charAt(2)), 1, 4,'W', (this.ciclos - ( 4 - Character.getNumericValue(numerosComoArray[i].charAt(8)))) );
					//	public ZombieLento(int x, int y, int resistencia, int danio,int velocidad,char letra,int ciclo) {

				}
				if(numerosComoArray[i].charAt(0) == 'X') {
					zom = new ZombieDeportista(Character.getNumericValue(numerosComoArray[i].charAt(4)), Character.getNumericValue(numerosComoArray[i].charAt(6)),Character.getNumericValue(numerosComoArray[i].charAt(2)), 1, 1,'X', (this.ciclos - Character.getNumericValue(numerosComoArray[i].charAt(8))) );
					//	public Nuez(int x, int y, int coste, int resistencia, int danio, int frecuencia,char letra,int ciclo ) {

				}
				this.numZombies = cont;
				objectList.aniadir(zom);
			}

			System.out.println("Game successfully loaded from file " + nombreArchLoad );



		}catch(FileContentsException  e) {
			String respuesta;
			respuesta = e.getMessage();
			System.out.println(respuesta);
		}
	}



	static void malContenido(Level level)throws FileContentsException{
		if((level == null)){
			throw new FileContentsException("Invalid level");
		}


	}
}
