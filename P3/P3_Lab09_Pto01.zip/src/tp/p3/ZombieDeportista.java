package tp.p3;


import commands.GameObjectList;
import commands.Zombies;

public class ZombieDeportista extends Zombies {

	//private int ciclo;
	
	public ZombieDeportista(int x, int y, int resistencia, int danio,int velocidad,char letra,int ciclo) {
		super(x,y,resistencia,danio,velocidad,letra,ciclo);
		//this.danio = danio;
		//this.velocidad = velocidad;
		//this.ciclo = ciclo;
	}
	
	
	public ZombieDeportista() {
		super("X","[Z]ombie deportista: speed: 1 Harm: 1 Life: 2 ");
	}
	
	
	
	public void avanza(Game game,BoardPrinter printer,GameObjectList objectList) {
		

			if(this.getVida() > 0 && printer.isEmpty(this.getX(), this.getY() -1,objectList)) { //si esta vivo y no tiene nada a la izquierda
				//printer.setBoardVacia(this.getX(),this.getY()); //borro del tablero donde estaba antes
				this.setY(this.getY() - 1); //modifico en la lista de zombies
			//	printer.setBoard(this.getLetra(), this.getX(),this.getY(),this.getVida());//modifico en tablero
				//template.setBoardVacia(zombielist.zom(i).getX(), zombielist.zom(i).getY()); //borro del tablero donde estaba antes
				}
			}				
		}
	
	

