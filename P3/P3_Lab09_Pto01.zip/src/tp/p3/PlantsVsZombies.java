package tp.p3;

import java.util.Random;


import java.util.Scanner;

import commands.GameObjectList;


public class PlantsVsZombies {
	private static Random seed;
	static int semilla;
	final static int soles = 50;
	static GameObjectList objectList;

	public static int getSoles() {
		return soles;
	}

	public static void main(String[] args) {
		Game game = null;
		objectList = new GameObjectList();
		//Level level = null;
		try { //evita errores por si pones una letra como semilla
			if(args.length == 1) {
				semilla = new Random().nextInt(1000);
				seed = new Random(semilla);
				if(args[0].equalsIgnoreCase("easy")) { 
					game = new Game(1,seed,Level.EASY,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,objectList,new ReleasePrinter(4,8,objectList,game));
				}
				else if(args[0].equalsIgnoreCase("hard")) { 
					game = new Game(1,seed,Level.HARD,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,new GameObjectList(),new ReleasePrinter(4,8,objectList,game));
				}
				else if(args[0].equalsIgnoreCase("insane")) game = new Game(1,seed,Level.INSANE,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,new GameObjectList(),new ReleasePrinter(4,8,objectList,game));


			}

			if(args.length == 2) {
				semilla = Integer.parseInt(args[1]);
				seed = new Random(semilla);
				if(args[0].equalsIgnoreCase("easy")) { 
					game = new Game(1,seed,Level.EASY,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,new GameObjectList(),new ReleasePrinter(4,8,objectList,game));
				}
				else if(args[0].equalsIgnoreCase("hard")) { 
					game = new Game(1,seed,Level.HARD,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,new GameObjectList(),new ReleasePrinter(4,8,objectList,game));
				}
				else if(args[0].equalsIgnoreCase("insane")) game = new Game(1,seed,Level.INSANE,new SuncoinManager(soles)/*,new GamePrinterTemplate(4,8)*/,new GameObjectList(),new ReleasePrinter(4,8,objectList,game));
				
			}



			try { //este try evita error si no pones easy, hard o insane
				Controller controlador = new Controller(game, new Scanner(System.in));
				controlador.run();

			}
				catch(NullPointerException e) {
					System.out.println("Usage: plantsVsZombies < EASY | HARD | INSANE > [seed] : level must be one of: EASY, HARD, INSANE ");
				}

			}
			catch(NumberFormatException e) {
				System.out.println("Usage: plantsVsZombies < EASY | HARD | INSANE > [seed]");
			}
		}

		public static Random getSeed() {
			return seed;
		}

		public static int getSemilla() {
			return semilla;
		}
	}
