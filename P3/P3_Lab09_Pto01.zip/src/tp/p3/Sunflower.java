package tp.p3;

import commands.GameObjectList;
import commands.Plants;

public class Sunflower extends Plants {
	
	
	
	
	/*
	private int x;
	private int y;
	private int coste;
	private int resistencia;
	private int danio;
	private int frecuencia;
	*/
	//private int ciclo;
	Game game;
	
	
	public Sunflower() {
		super("S","[S]unflower: Cost: 20 suncoins Harm: 0 ");
	}
	public Sunflower(int x, int y, int coste, int resistencia, int danio, int frecuencia, int ciclo,char letra ) {
		super(x,y,resistencia,coste,frecuencia,danio,letra,ciclo);
		//this.x = x;
		//this.y = y;
		//this.coste = coste;
		//this.resistencia = resistencia;
		//this.danio = danio;
		//this.frecuencia = frecuencia;
		//this.ciclo = ciclo;
	}


/*
	public int getResistencia() {
		return resistencia;
	}
*/
	/*
	public int getCiclo() {
		return  ciclo;
	}
	*/
	GameObjectList objectList;
	@Override
	public void ataca(GameObjectList objectList,BoardPrinter printer,Game game) {
		// TODO Auto-generated method stub
		
	}


/*
	public int getX() {
		return x;
	}



	public void setX(int x) {
		this.x = x;
	}



	public void setResistencia(int resistencia) {
		this.resistencia = resistencia;
	}



	public int getY() {
		return y;
	}



	public void setY(int y) {
		this.y = y;
	}



	public int getCoste() {
		return coste;
	}



	public void setCoste(int coste) {
		this.coste = coste;
	}



	public int getDanio() {
		return danio;
	}



	public void setDanio(int danio) {
		this.danio = danio;
	}



	public int getFrecuencia() {
		return frecuencia;
	}



	public void setFrecuencia(int frecuencia) {
		this.frecuencia = frecuencia;
	}
	
	GameObjectList objectList;
	SuncoinManager suncoin;
	/*
public void update() {
		
		sumaSoles();
		//ataca();
		//atacaZombie();
		//avanza();
		//muerte();
		//numZombies = ZombieManager.computerAction(level,rand,template,zombielist,numZombies,zom,quedan); // aparicion de zombie y devuelvo el contador de zombies
		//ciclos++;
		//System.out.println("Random seed used: " + PlantsVsZombies.getSemilla());
		//System.out.println("Number of cycles: " + (ciclos-1));
		//System.out.println("Sun coins: " + suncoin.getSuncoins());
		//quedan = zombiesQuedan();
		//System.out.println("Remaining zombies: " + quedan); //zombies que quedan por salir
		
		//System.out.println(template.toString());
	}

public void sumaSoles() { // para cada girasol suma soles si llevan dos turnos sin dar
	
	for(int i = 0; i < objectList.ultimaPos(); i++) {
		if(objectList.getObjeto(i).getLetra() == 's') {
		if((game.getCiclos() - objectList.getObjeto(i).getCiclo(objectList.getObjeto(i)) %3 == 0 && game.getCiclos() -  objectList.getObjeto(i).getCiclo(objectList.getObjeto(i)) != 0) ) { //si desde que le an puesto, lleva un turno sin dar
			suncoin.setSuncoins(suncoin.getSuncoins() + objectList.getObjeto(i).getFrecuenciaPlanta()); //si le toca hace soles totales + 10
			
		}
	}
	}

}
*/
}
