package exceptions;

public class CommandExecuteException extends Exception {

	String mensage;
	
	public CommandExecuteException(String msg) {
		mensage = msg;
	}
	
	
	public String getMessage() {
		return mensage;
		
	}
	
}
