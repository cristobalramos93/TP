package exceptions;

public class FileContentsException extends Exception {
	
	String mensage;
	public FileContentsException(String msg) {
		mensage = msg;
	}
	
	public String getMessage() {
		return mensage;
		
	}
	
}

