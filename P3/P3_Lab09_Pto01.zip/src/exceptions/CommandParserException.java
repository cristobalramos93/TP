package exceptions;

public class CommandParserException extends Exception {
	
	String mensage;
	public CommandParserException(String msg) {
		mensage = msg;
	}
	
	public String getMessage() {
		return mensage;
		
	}
	
}
